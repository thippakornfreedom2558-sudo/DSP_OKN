package com.okn.golopinedsp;

import java.util.ArrayList;
import java.util.List;

/** BP1048 family framing used by public examples: A5 5A [control] [len] [payload] 16. */
public final class DspProtocol {
    private DspProtocol() {}
    public static byte[] frame(int control, byte[] payload) {
        if (payload == null) payload = new byte[0];
        if (payload.length > 255) throw new IllegalArgumentException("payload too long");
        byte[] out = new byte[5 + payload.length];
        out[0]=(byte)0xA5; out[1]=(byte)0x5A; out[2]=(byte)control; out[3]=(byte)payload.length;
        System.arraycopy(payload,0,out,4,payload.length); out[out.length-1]=0x16; return out;
    }
    public static byte[] firmwareInfoRequest() { return frame(0x00, new byte[0]); }
    public static String hex(byte[] b) { StringBuilder s=new StringBuilder(); for(byte x:b) s.append(String.format("%02X ",x&255)); return s.toString().trim(); }
    public static List<byte[]> split(byte[] data) {
        List<byte[]> frames=new ArrayList<>(); int i=0;
        while(i+5<=data.length){ if((data[i]&255)==0xA5 && (data[i+1]&255)==0x5A){int n=data[i+3]&255; int end=i+5+n-0; if(i+5+n<=data.length && (data[i+4+n]&255)==0x16){byte[] f=new byte[5+n];System.arraycopy(data,i,f,0,f.length);frames.add(f);i=f.length+i;continue;}} i++; }
        return frames;
    }
}
