package com.okn.golopinedsp;

import android.Manifest;import android.bluetooth.*;import android.bluetooth.le.*;import android.content.*;import android.content.pm.PackageManager;import android.os.Build;import android.os.Handler;import android.os.Looper;
import java.util.*;

public class BleController {
    public interface Listener { void onLog(String s); void onState(String s); void onDevice(String name,String address); }
    public static final UUID SERVICE_AB00=UUID.fromString("0000AB00-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB01=UUID.fromString("0000AB01-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB02=UUID.fromString("0000AB02-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB03=UUID.fromString("0000AB03-0000-1000-8000-00805F9B34FB");
    private final Context ctx; private final Listener listener; private BluetoothGatt gatt; private BluetoothGattCharacteristic tx,rx; private boolean scanning;
    private final Handler h=new Handler(Looper.getMainLooper());
    public BleController(Context c,Listener l){ctx=c;listener=l;}
    private boolean can(String p){return Build.VERSION.SDK_INT<23 || ctx.checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
    public void scan(){ if(!can(Manifest.permission.BLUETOOTH_SCAN)){listener.onLog("ต้องอนุญาต Nearby devices ก่อน");return;} BluetoothManager bm=(BluetoothManager)ctx.getSystemService(Context.BLUETOOTH_SERVICE); BluetoothAdapter a=bm.getAdapter(); if(a==null||!a.isEnabled()){listener.onLog("เปิด Bluetooth ก่อน");return;} if(scanning)return; scanning=true; listener.onState("กำลังค้นหา LE-DSTe..."); a.getBluetoothLeScanner().startScan(scanCb); h.postDelayed(this::stopScan,8000); }
    public void stopScan(){ if(!scanning)return; scanning=false; if(can(Manifest.permission.BLUETOOTH_SCAN)){BluetoothManager bm=(BluetoothManager)ctx.getSystemService(Context.BLUETOOTH_SERVICE);bm.getAdapter().getBluetoothLeScanner().stopScan(scanCb);} listener.onState("พร้อม"); }
    private final ScanCallback scanCb=new ScanCallback(){@Override public void onScanResult(int type,ScanResult r){
    BluetoothDevice d=r.getDevice();
    String n=null;
    try{n=Build.VERSION.SDK_INT>=31&&can(Manifest.permission.BLUETOOTH_CONNECT)?d.getName():null;}catch(Exception e){}
    if(n==null && r.getScanRecord()!=null)n=r.getScanRecord().getDeviceName();
    if(n==null||n.trim().isEmpty())n="(ไม่ประกาศชื่อ)";
    listener.onDevice(n,d.getAddress());
    String u=n.toUpperCase(Locale.US);
    boolean known=u.contains("DST")||u.contains("GOLO")||u.contains("LE-DST");
    boolean hasAb00=false;
    try{hasAb00=r.getScanRecord()!=null && r.getScanRecord().getServiceUuids()!=null && r.getScanRecord().getServiceUuids().toString().toUpperCase(Locale.US).contains("AB00");}catch(Exception e){}
    if(known||hasAb00){stopScan();connect(d);}
}};
    public void connect(BluetoothDevice d){ if(!can(Manifest.permission.BLUETOOTH_CONNECT)){listener.onLog("ไม่มีสิทธิ์ Bluetooth Connect");return;} listener.onState("กำลังเชื่อมต่อ "+safeName(d)); gatt=d.connectGatt(ctx,false,cb); }
    private String safeName(BluetoothDevice d){try{return d.getName()+" "+d.getAddress();}catch(Exception e){return d.getAddress();}}
    public void disconnect(){if(gatt!=null){gatt.disconnect();gatt.close();gatt=null;}tx=rx=null;listener.onState("ตัดการเชื่อมต่อ");}
    public void requestFirmware(){ if(tx==null){listener.onLog("ยังไม่มีช่องส่งข้อมูล");return;} write(DspProtocol.firmwareInfoRequest()); }
    public void write(byte[] data){
        if(tx==null||gatt==null){listener.onLog("ยังไม่ได้เชื่อมต่อ DSP");return;}
        if(!can(Manifest.permission.BLUETOOTH_CONNECT)){listener.onLog("ไม่มีสิทธิ์ Bluetooth Connect");return;}
        int props=tx.getProperties();
        if((props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0){
            tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
        }else if((props & BluetoothGattCharacteristic.PROPERTY_WRITE)!=0){
            tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        }else{
            listener.onLog("TX characteristic เขียนไม่ได้: "+tx.getUuid()+" props=0x"+Integer.toHexString(props));
            return;
        }
        tx.setValue(data);
        boolean ok=gatt.writeCharacteristic(tx);
        listener.onLog("TX "+DspProtocol.hex(data)+" -> "+tx.getUuid()+" type="+tx.getWriteType()+(ok?"":" [FAILED]"));
    }
    private final BluetoothGattCallback cb=new BluetoothGattCallback(){
      @Override public void onConnectionStateChange(BluetoothGatt g,int s,int n){if(n==BluetoothProfile.STATE_CONNECTED){listener.onState("เชื่อมต่อแล้ว — กำลังอ่าน Services");if(can(Manifest.permission.BLUETOOTH_CONNECT))g.discoverServices();}else if(n==BluetoothProfile.STATE_DISCONNECTED){listener.onState("หลุดการเชื่อมต่อ");}}
      @Override public void onServicesDiscovered(BluetoothGatt g,int status){if(status!=BluetoothGatt.GATT_SUCCESS)return; BluetoothGattService s=g.getService(SERVICE_AB00); if(s!=null){tx=s.getCharacteristic(CHAR_AB01);rx=s.getCharacteristic(CHAR_AB02); if(rx==null)rx=s.getCharacteristic(CHAR_AB03);} if(tx==null||rx==null){for(BluetoothGattService ss:g.getServices())for(BluetoothGattCharacteristic c:ss.getCharacteristics()){int p=c.getProperties();if(tx==null&&(p&(BluetoothGattCharacteristic.PROPERTY_WRITE|BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE))!=0)tx=c;if(rx==null&&(p&(BluetoothGattCharacteristic.PROPERTY_NOTIFY|BluetoothGattCharacteristic.PROPERTY_INDICATE))!=0)rx=c;}} StringBuilder diag=new StringBuilder("GATT: ").append(g.getServices().size()).append(" services");
        for(BluetoothGattService ss:g.getServices()){
            diag.append(" | S=").append(ss.getUuid());
            for(BluetoothGattCharacteristic cc:ss.getCharacteristics()){
                diag.append(" C=").append(cc.getUuid()).append("/p0x").append(Integer.toHexString(cc.getProperties()));
            }
        }
        listener.onLog(diag.toString());
        listener.onLog("TX="+(tx==null?"none":tx.getUuid())+" RX="+(rx==null?"none":rx.getUuid())); if(rx!=null && can(Manifest.permission.BLUETOOTH_CONNECT)){g.setCharacteristicNotification(rx,true);BluetoothGattDescriptor d=rx.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805F9B34FB"));if(d!=null){d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);g.writeDescriptor(d);}} listener.onState("พร้อมควบคุม DSP — กดค้นหาอีกครั้งได้");}
      @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){byte[] b=c.getValue();listener.onLog("RX "+DspProtocol.hex(b));}
    };
}
