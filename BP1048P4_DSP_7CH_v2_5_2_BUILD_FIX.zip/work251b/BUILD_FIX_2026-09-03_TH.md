# Build Fix v2.5.2

แก้ปัญหา Java compile ที่ GitHub Actions พบ:

- เพิ่มเมธอด `applyPreset(int)` ซึ่งถูกเรียกจากหน้า PRESET แต่หายไปจาก MainActivity.java
- ปรับ versionCode เป็น 52 / versionName 2.5.2
- ปรับชื่อ APK artifact เป็น `BP1048P4-DSP-7CH-v2.5.2-APK`
- ใช้ AGP 8.7.3 + Gradle 8.9 + Java 17 ตาม workflow เดิม

หมายเหตุ: EQ/Crossover/Delay/Mixer/Preset ในรุ่นนี้ยังเป็น profile ภายในแอปจนกว่าจะยืนยัน OEM BLE packet mapping ของ GoloPine.
