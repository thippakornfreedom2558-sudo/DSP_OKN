package com.okn.golopinedsp;

import android.Manifest;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import java.util.*;

public class BleController {
    private final StringBuilder debugLog = new StringBuilder();
    private static final int MAX_LOG = 12000;

    private void logLine(String x) {
        synchronized (debugLog) {
            debugLog.append(x).append('\n');
            if (debugLog.length() > MAX_LOG) {
                debugLog.delete(0, debugLog.length() - MAX_LOG);
            }
        }
    }

    public String getLogText() {
        synchronized (debugLog) { return debugLog.toString(); }
    }

    public void clearLog() {
        synchronized (debugLog) { debugLog.setLength(0); }
    }

    public interface Listener { void onLog(String s); void onState(String s); void onDevice(String name,String address,int rssi); }
    public static final UUID SERVICE_AB00=UUID.fromString("0000AB00-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB01=UUID.fromString("0000AB01-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB02=UUID.fromString("0000AB02-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB03=UUID.fromString("0000AB03-0000-1000-8000-00805F9B34FB");
    public static final UUID CCCD=UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");
    private final Context ctx; private final Listener listener; private BluetoothGatt gatt; private BluetoothGattCharacteristic tx,rx; private boolean scanning;
    private final Handler h=new Handler(Looper.getMainLooper());
    public BleController(Context c,Listener l){ctx=c;listener=l;}
    private boolean can(String p){return Build.VERSION.SDK_INT<23 || ctx.checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
    public void scan(){
        if(Build.VERSION.SDK_INT>=31&&!can(Manifest.permission.BLUETOOTH_SCAN)){listener.onLog("ต้องอนุญาต Nearby devices");return;}
        BluetoothManager bm=(BluetoothManager)ctx.getSystemService(Context.BLUETOOTH_SERVICE); BluetoothAdapter a=bm.getAdapter();
        if(a==null||!a.isEnabled()){listener.onLog("เปิด Bluetooth ก่อน");return;} if(scanning)return;
        scanning=true; listener.onState("กำลังค้นหา BLE..."); a.getBluetoothLeScanner().startScan(scanCb); h.postDelayed(this::stopScan,10000);
    }
    public void stopScan(){if(!scanning)return; scanning=false; try{BluetoothManager bm=(BluetoothManager)ctx.getSystemService(Context.BLUETOOTH_SERVICE);bm.getAdapter().getBluetoothLeScanner().stopScan(scanCb);}catch(Exception ignored){} listener.onState("สแกนเสร็จ");}
    private final ScanCallback scanCb=new ScanCallback(){@Override public void onScanResult(int type,ScanResult r){
        BluetoothDevice d=r.getDevice(); String n=null; try{if(Build.VERSION.SDK_INT>=31&&can(Manifest.permission.BLUETOOTH_CONNECT))n=d.getName();}catch(Exception ignored){}
        if((n==null||n.trim().isEmpty())&&r.getScanRecord()!=null)n=r.getScanRecord().getDeviceName(); if(n==null||n.trim().isEmpty())n="(ไม่มีชื่อ)";
        listener.onDevice(n,d.getAddress(),r.getRssi()); String u=n.toUpperCase(Locale.US); boolean known=u.contains("GOLO")||u.contains("DSP")||u.contains("DST");
        boolean ab=false; try{ab=r.getScanRecord()!=null&&String.valueOf(r.getScanRecord().getServiceUuids()).toUpperCase(Locale.US).contains("AB00");}catch(Exception ignored){}
        if(known||ab){stopScan(); connect(d);}
    }};
    public void connect(BluetoothDevice d){if(!can(Manifest.permission.BLUETOOTH_CONNECT)){listener.onLog("ไม่มี Bluetooth Connect permission");return;} closeOnly(); listener.onState("กำลังเชื่อมต่อ "+d.getAddress()); gatt=d.connectGatt(ctx,false,cb,BluetoothDevice.TRANSPORT_LE);}
    private void closeOnly(){if(gatt!=null){try{gatt.disconnect();gatt.close();}catch(Exception ignored){} gatt=null;}tx=null;rx=null;}
    public void disconnect(){closeOnly();listener.onState("ตัดการเชื่อมต่อ");}
    public boolean isConnected(){return gatt!=null&&tx!=null;}
    public void addLog(String s){ listener.onLog(s); }
    public void requestFirmware(){write(DspProtocol.firmwareInfoRequest());}
    public void requestAll(){int[] cs={0x00,0x01,0x03,0x04,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D}; for(int c:cs)write(DspProtocol.query(c)); write(DspProtocol.effectListQuery());}
    public void write(byte[] data){
        if(gatt==null||tx==null){listener.onLog("ยังไม่มี TX characteristic");return;}
        if(!can(Manifest.permission.BLUETOOTH_CONNECT)){listener.onLog("ไม่มี Bluetooth Connect permission");return;}
        int p=tx.getProperties(); int type;
        if((p&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0) type=BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
        else if((p&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0) type=BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
        else {listener.onLog("TX เขียนไม่ได้ props=0x"+Integer.toHexString(p));return;}
        try{
            int rc;
            if(Build.VERSION.SDK_INT>=33) rc=gatt.writeCharacteristic(tx,data,type); else {tx.setWriteType(type);tx.setValue(data);rc=gatt.writeCharacteristic(tx)?0:-1;}
            listener.onLog("TX "+DspProtocol.hex(data)+" | "+tx.getUuid()+" | "+(type==1?"NO_RESPONSE":"WRITE")+" | rc="+rc);
        }catch(Exception e){listener.onLog("TX exception: "+e.getMessage());}
    }
    private final BluetoothGattCallback cb=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
            listener.onLog("GATT state="+newState+" status=0x"+Integer.toHexString(status));
            if(newState==BluetoothProfile.STATE_CONNECTED){listener.onState("เชื่อมต่อแล้ว • อ่าน Services..."); if(can(Manifest.permission.BLUETOOTH_CONNECT))g.discoverServices();}
            else if(newState==BluetoothProfile.STATE_DISCONNECTED){listener.onState("หลุดการเชื่อมต่อ");tx=null;rx=null;}
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){
            if(status!=BluetoothGatt.GATT_SUCCESS){listener.onLog("discoverServices failed status="+status);return;}
            StringBuilder all=new StringBuilder();
            for(BluetoothGattService s:g.getServices()){all.append("S ").append(s.getUuid()).append("\n"); for(BluetoothGattCharacteristic c:s.getCharacteristics()) all.append("  C ").append(c.getUuid()).append(" p=0x").append(Integer.toHexString(c.getProperties())).append("\n");}
            listener.onLog(all.toString().trim());
            BluetoothGattService s=g.getService(SERVICE_AB00);
            if(s!=null){tx=s.getCharacteristic(CHAR_AB01);rx=s.getCharacteristic(CHAR_AB02);if(rx==null)rx=s.getCharacteristic(CHAR_AB03);}
            if(tx==null||rx==null) for(BluetoothGattService ss:g.getServices())for(BluetoothGattCharacteristic c:ss.getCharacteristics()){int p=c.getProperties();if(tx==null&&((p&8)!=0||(p&4)!=0))tx=c;if(rx==null&&((p&16)!=0||(p&32)!=0))rx=c;}
            listener.onLog("SELECT TX="+(tx==null?"none":tx.getUuid())+" RX="+(rx==null?"none":rx.getUuid()));
            if(rx!=null&&can(Manifest.permission.BLUETOOTH_CONNECT)){try{g.setCharacteristicNotification(rx,true);BluetoothGattDescriptor d=rx.getDescriptor(CCCD);if(d!=null){d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);g.writeDescriptor(d);}}catch(Exception e){listener.onLog("notify error: "+e.getMessage());}}
            listener.onState("พร้อมใช้งาน • กด READ DSP เพื่ออ่านข้อมูล");
        }
        @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int status){listener.onLog("WRITE CALLBACK "+c.getUuid()+" status=0x"+Integer.toHexString(status));}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){byte[] b=c.getValue();listener.onLog("RX "+DspProtocol.hex(b)); for(byte[] f:DspProtocol.split(b))listener.onLog("FRAME control=0x"+String.format(Locale.US,"%02X",DspProtocol.control(f))+" len="+(f.length-5));}
        @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int status){listener.onLog("READ "+c.getUuid()+" status=0x"+Integer.toHexString(status));}
    };
}
