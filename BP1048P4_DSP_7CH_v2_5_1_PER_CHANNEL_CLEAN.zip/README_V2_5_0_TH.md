# BP1048P4 DSP PRO v2.5.0

ปรับ UI ให้สะอาดและให้ EQ / CROSSOVER / DELAY / MIXER / PRESET เลือก CH1–CH7 แยกกัน

- Master Volume ยังคง Android/Bluetooth Volume ตามรุ่นที่ใช้งานได้
- ตัด CH1–CH7 Volume/Fader ออกจากหน้า MAIN ตามคำขอ
- EQ: เลือก CH1–CH7 และปรับ 15-band แยกช่อง
- Crossover: เลือก CH1–CH7 และปรับ HPF/LPF แยกช่อง
- Delay: เลือก CH1–CH7 และปรับระยะ/เวลาแยกช่อง
- Mixer: เลือก CH1–CH7 และปรับ L/R routing แยกช่อง
- Preset: เลือก CH1–CH7 และโหลด preset ให้เฉพาะช่องที่เลือก

หมายเหตุ: ค่าปรับเหล่านี้บันทึกใน DSP profile ภายในแอป ส่วนการเขียน Gain/EQ/Crossover/Delay/Mixer เข้า DSP hardware จริงยังต้องยืนยัน OEM session/packet ของ GoloPine ก่อน
