# BP1048P4 DSP PRO v2.5.1

หน้าจอใช้งานสะอาดขึ้น และเลือก CH1–CH7 แยกกันสำหรับ EQ 15 Band, Crossover, Delay, Mixer และ Preset ได้ โดยค่าจะบันทึกแยกช่องในเครื่อง

หมายเหตุสำคัญ: การเขียนค่าเหล่านี้เข้า DSP จริงผ่าน BLE ของ GoloPine ยังต้องใช้ OEM authenticated/encrypted session ที่ยืนยันแล้ว จึงยังไม่ส่ง packet ที่เดาเอง
