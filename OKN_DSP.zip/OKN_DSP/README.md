# OKN_DSP

Android DSP Controller project for MVSilicon BP1048P4 7CH DSP.

## Upload from phone
1. Extract ZIP.
2. Upload the whole OKN_DSP folder contents to a new GitHub repository.
3. Open Actions tab.
4. Run Android Build workflow.
5. Download OKN_DSP.apk from Artifact.

## Install APK
Enable installing apps from unknown sources, then install OKN_DSP.apk.

Architecture:
- Kotlin
- MVVM
- Jetpack Compose
- DSP communication abstraction for Bluetooth / USB / UART

Note:
Protocol commands for BP1048P4 depend on the DSP firmware/vendor protocol. The communication layer is prepared for adding real commands.
