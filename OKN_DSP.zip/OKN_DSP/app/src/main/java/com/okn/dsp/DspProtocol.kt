package com.okn.dsp

// Communication abstraction for MVSilicon BP1048P4
interface DspProtocol {
 fun connect()
 fun disconnect()
 fun send(command: ByteArray)
 fun read(): ByteArray?
}

// Future implementations:
// BluetoothProtocol
// UsbHidProtocol
// UartProtocol
