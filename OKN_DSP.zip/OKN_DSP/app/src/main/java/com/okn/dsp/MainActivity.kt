package com.okn.dsp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*

class MainActivity: ComponentActivity(){
 override fun onCreate(savedInstanceState: Bundle?){
  super.onCreate(savedInstanceState)
  setContent{
   DSPControllerUI()
  }
 }
}

@Composable
fun DSPControllerUI(){
 var master by remember { mutableStateOf(-12.5f) }
 MaterialTheme{
  Surface {
   Column {
    Text("OKN_DSP  BP1048P4 7CH DSP")
    Text("Connected: Bluetooth / USB / UART")
    Slider(value=master, onValueChange={master=it})
    repeat(7){ ch ->
      Text("CH${ch+1}  Volume  Mute  Delay  EQ  Crossover")
    }
   }
  }
 }
}
