@echo off
gradlew.bat placeholder
