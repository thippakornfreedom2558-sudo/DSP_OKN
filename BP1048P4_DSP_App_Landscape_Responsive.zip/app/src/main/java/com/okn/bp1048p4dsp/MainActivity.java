package com.okn.bp1048p4dsp;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    DSPView view;
    BluetoothAdapter bt;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        view = new DSPView(this);
        setContentView(view);
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, 20);
        }
        BluetoothManager bm = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        bt = bm == null ? null : bm.getAdapter();
    }
}

class DSPView extends View {
    Paint p = new Paint(3);
    Paint stroke = new Paint(3);
    float downX, downY, scrollX=0, maxX;
    int page=0;
    String[] pages={"MAIN","EQ","CROSSOVER","DELAY","MIXER","PRESET","SETTINGS"};
    int[] accent={0xFF00BFFF,0xFF00BFFF,0xFF00BFFF,0xFF00BFFF,0xFF00BFFF,0xFFB8A1FF,0xFF00BFFF};
    String[] ch={"CH1\nFront L","CH2\nFront R","CH3\nSUB","CH4\nRear L","CH5\nRear R","CH6\nAUX L","CH7\nAUX R"};
    float[] gain={-2,-2,-5,-3,-3,-6,-6};
    boolean[] mute=new boolean[7];
    float master=-12.5f;

    DSPView(Context c){ super(c); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); stroke.setStyle(Paint.Style.STROKE); setBackgroundColor(Color.BLACK); }

    void fill(Canvas c,int color,float l,float t,float r,float b,float rad){
        p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);
    }
    void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){
        p.setTypeface(Typeface.create("sans",Typeface.NORMAL));p.setTextSize(size);p.setColor(color);p.setTextAlign(align);p.setStyle(Paint.Style.FILL);
        for(String line:s.split("\n")){ c.drawText(line,x,y,p); y+=size*1.12f; }
    }
    void line(Canvas c,float x1,float y1,float x2,float y2,int color,float w){
        stroke.setColor(color);stroke.setStrokeWidth(w);c.drawLine(x1,y1,x2,y2,stroke);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);

        // Responsive landscape layout:
        // All UI is designed on a fixed 1280x720 canvas, then uniformly
        // scaled to the actual device viewport so nothing is clipped.
        float vw = getWidth();
        float vh = getHeight();
        final float BASE_W = 1280f;
        final float BASE_H = 720f;

        float scale = Math.min(vw / BASE_W, vh / BASE_H);
        float ox = (vw - BASE_W * scale) / 2f;
        float oy = (vh - BASE_H * scale) / 2f;

        c.save();
        c.translate(ox, oy);
        c.scale(scale, scale);

        drawTop(c, BASE_W);
        c.save();
        c.clipRect(0, 150, BASE_W, BASE_H - 72);
        c.translate(-page * BASE_W, 0);
        for(int i=0;i<pages.length;i++) {
            drawPage(c, i, i * BASE_W, 150, BASE_W, BASE_H);
        }
        c.restore();
        drawNav(c, BASE_W, BASE_H);

        c.restore();
    }

    void drawTop(Canvas c,float w){
        fill(c,0xFF101418,12,8,w-12,140,18);
        text(c,"⌁",38,55,38,0xFF00BFFF,Paint.Align.CENTER);
        text(c,"Connected",65,36,14,0xFF8DFF5A,Paint.Align.LEFT);
        text(c,"เชื่อมต่อแล้ว",65,58,12,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"Device",180,32,11,0xFFAAAAAA,Paint.Align.LEFT);
        text(c,"BP1048P4 7CH DSP",180,53,14,Color.WHITE,Paint.Align.LEFT);
        text(c,"FW: 1.2.6",180,75,12,0xFFAAAAAA,Paint.Align.LEFT);
        text(c,"Master Volume",w*0.50f,31,12,0xFFCCCCCC,Paint.Align.CENTER);
        text(c,String.format(Locale.US,"%.1f dB",master),w*0.50f,59,20,Color.WHITE,Paint.Align.CENTER);
        line(c,w*.38f,88,w*.65f,88,0xFF555A60,5);
        line(c,w*.38f,88,w*.50f,88,0xFF00BFFF,5);
        fill(c,0xFF1C2328,w*.70f,22,w*.86f,78,12);
        text(c,"🔇 Mute",w*.78f,53,13,Color.WHITE,Paint.Align.CENTER);
        fill(c,0xFF182126,w*.87f,22,w*.985f,78,10);
        text(c,"▣ บันทึก DSP",w*.927f,51,12,Color.WHITE,Paint.Align.CENTER);
        fill(c,0xFF182126,w*.87f,86,w*.985f,130,10);
        text(c,"▱ อ่านค่าจาก DSP",w*.927f,113,11,Color.WHITE,Paint.Align.CENTER);
    }

    void drawPage(Canvas c,int i,float ox,float top,float w,float h){
        if(i==0) drawMain(c,ox,top,w,h);
        else if(i==1) drawEQ(c,ox,top,w,h);
        else if(i==2) drawCross(c,ox,top,w,h);
        else if(i==3) drawDelay(c,ox,top,w,h);
        else if(i==4) drawMixer(c,ox,top,w,h);
        else if(i==5) drawPreset(c,ox,top,w,h);
        else drawSettings(c,ox,top,w,h);
    }

    void drawMain(Canvas c,float x,float y,float w,float h){
        float cw=(w-30)/7f;
        for(int i=0;i<7;i++){
            float l=x+8+i*cw;
            fill(c,0xFF11171B,l,y+8,l+cw-4,y+260,10);
            p.setColor(accent[i==2?1:0]);c.drawRect(l,y+8,l+cw-4,y+12,p);
            text(c,ch[i],l+cw/2-2,y+36,13,Color.WHITE,Paint.Align.CENTER);
            text(c,String.format(Locale.US,"%.1f dB",gain[i]),l+cw/2-2,y+86,15,Color.WHITE,Paint.Align.CENTER);
            line(c,l+cw/2-2,y+112,l+cw/2-2,y+220,0xFF555A60,4);
            line(c,l+cw/2-2,y+170,l+cw/2-2,y+220,accent[i==2?1:0],3);
            fill(c,0xFFE6EAF0,l+cw/2-11,y+163,l+cw/2+7,y+181,6);
            fill(c,0xFF1B2227,l+cw/2-27,y+230,l+cw/2+27,y+255,8);
            text(c,mute[i]?"UNMUTE":"Mute",l+cw/2,y+248,10,Color.WHITE,Paint.Align.CENTER);
        }
        section(c,x,y+282,w,"15-Band Parametric EQ");
        drawGraph(c,x+25,y+320,w-50,200);
    }

    void section(Canvas c,float x,float y,float w,String s){
        text(c,s,x+15,y+24,16,0xFF00BFFF,Paint.Align.LEFT);
        line(c,x+15,y+38,x+w-15,y+38,0xFF273239,1);
    }
    void drawGraph(Canvas c,float x,float y,float w,float h){
        fill(c,0xFF0D1317,x,y,x+w,y+h,10);
        for(int k=0;k<6;k++) line(c,x,y+h*k/5f,x+w,y+h*k/5f,0xFF222B30,1);
        for(int k=0;k<9;k++) line(c,x+w*k/8f,y,x+w*k/8f,y+h,0xFF20282D,1);
        float[] g={0,1.5f,3,2,0,-1.5f,0,1,2,1.5f,0,-1,.5f,2,0};
        float prevX=x,prevY=y+h/2;
        for(int i=0;i<g.length;i++){
            float px=x+i*(w/(g.length-1));
            float py=y+h/2-g[i]*h/14f;
            line(c,prevX,prevY,px,py,0xFF00BFFF,3);
            fill(c,0xFF09151A,px-10,py-10,px+10,py+10,10);
            text(c,""+(i+1),px,py+4,10,0xFF00BFFF,Paint.Align.CENTER);
            prevX=px;prevY=py;
        }
    }
    void drawEQ(Canvas c,float x,float y,float w,float h){
        section(c,x,y,w,"EQ  •  15-Band Parametric EQ");
        text(c,"รีเซ็ต EQ",x+w-75,y+25,11,Color.WHITE,Paint.Align.CENTER);
        drawGraph(c,x+20,y+55,w-40,220);
        float yy=y+295;
        String[] f={"20","25","40","63","100","160","250","400","630","1k","1.6k","2.5k","4k","6.3k","16k"};
        text(c,"Band",x+18,yy,12,0xFFAAAAAA,Paint.Align.LEFT);
        for(int i=0;i<15;i++) text(c,""+(i+1),x+75+i*(w-100)/14f,yy,11,Color.WHITE,Paint.Align.CENTER);
        text(c,"Freq(Hz)",x+18,yy+32,11,0xFFAAAAAA,Paint.Align.LEFT);
        for(int i=0;i<15;i++) text(c,f[i],x+75+i*(w-100)/14f,yy+32,10,Color.WHITE,Paint.Align.CENTER);
        text(c,"Gain(dB)",x+18,yy+64,11,0xFFAAAAAA,Paint.Align.LEFT);
        for(int i=0;i<15;i++) text(c,String.format(Locale.US,"%.1f",new float[]{0,1.5f,3,2,0,-1.5f,0,1,2,1.5f,0,-1,.5f,2,0}[i]),x+75+i*(w-100)/14f,yy+64,10,Color.WHITE,Paint.Align.CENTER);
        for(int i=0;i<7;i++){ float yy2=y+410+i*56; fill(c,0xFF10171B,x+15,yy2,x+w-15,yy2+46,9); text(c,ch[i],x+30,yy2+29,12,Color.WHITE,Paint.Align.LEFT); }
    }
    void drawCross(Canvas c,float x,float y,float w,float h){
        section(c,x,y,w,"CROSSOVER");
        text(c,"CH1  Front L",x+20,y+70,14,Color.WHITE,Paint.Align.LEFT);
        row(c,x+20,y+105,"High Pass (HPF)","80 Hz","24 dB/Oct");
        row(c,x+20,y+160,"Low Pass (LPF)","20 kHz","24 dB/Oct");
        drawGraph(c,x+w*.55f,y+60,w*.38f,240);
        for(int i=0;i<7;i++){ row(c,x+20,y+250+i*58,ch[i].replace("\n"," "),i==2?"80 Hz":"80 Hz","24 dB/Oct"); }
    }
    void row(Canvas c,float x,float y,String a,String b,String d){
        text(c,a,x,y,12,0xFFCCCCCC,Paint.Align.LEFT);
        fill(c,0xFF172027,x+150,y-18,x+235,y+10,8); text(c,b,x+192,y,11,Color.WHITE,Paint.Align.CENTER);
        fill(c,0xFF172027,x+245,y-18,x+340,y+10,8); text(c,d,x+292,y,10,Color.WHITE,Paint.Align.CENTER);
    }
    void drawDelay(Canvas c,float x,float y,float w,float h){
        section(c,x,y,w,"DELAY");
        text(c,"หน่วย   cm    inch    ms",x+20,y+70,13,Color.WHITE,Paint.Align.LEFT);
        fill(c,0xFF11171B,x+w*.36f,y+70,x+w*.64f,y+310,18);
        text(c,"🚗",x+w*.50f,y+205,64,Color.WHITE,Paint.Align.CENTER);
        for(int i=0;i<7;i++){
            float bx=(i==2)?x+w*.42f:x+20+(i%2)*(w-190);
            float by=y+105+(i/2)*75;
            fill(c,0xFF11171B,bx,by,bx+145,by+60,10);
            text(c,ch[i].replace("\n"," "),bx+8,by+20,10,Color.WHITE,Paint.Align.LEFT);
            text(c,i==2?"150.0 cm":(i<2?"82.0 cm":"120.0 cm"),bx+8,by+42,14,Color.WHITE,Paint.Align.LEFT);
        }
    }
    void drawMixer(Canvas c,float x,float y,float w,float h){
        section(c,x,y,w,"MIXER");
        for(int i=0;i<7;i++){
            float yy=y+60+i*65;
            text(c,ch[i].replace("\n"," "),x+20,yy,12,Color.WHITE,Paint.Align.LEFT);
            line(c,x+105,yy-5,x+w-65,yy-5,0xFF4B555C,4);
            line(c,x+105,yy-5,x+w-105,yy-5,0xFF00BFFF,3);
            fill(c,0xFFE8ECF2,x+w-112,yy-13,x+w-96,yy+3,8);
            text(c,"100",x+w-35,yy,11,Color.WHITE,Paint.Align.CENTER);
        }
    }
    void drawPreset(Canvas c,float x,float y,float w,float h){
        section(c,x,y,w,"PRESET");
        String[] ps={"User 1","User 2","User 3","Rock","Pop","Jazz","Classic","Flat"};
        for(int i=0;i<8;i++){
            float yy=y+60+i*48;
            fill(c,i==0?0xFF123B4B:0xFF11171B,x+18,yy,x+w*.65f,yy+40,8);
            text(c,""+(i+1),x+35,yy+25,11,0xFFAAAAAA,Paint.Align.CENTER);
            text(c,ps[i],x+65,yy+25,12,Color.WHITE,Paint.Align.LEFT);
            text(c,"⋯",x+w*.61f,yy+25,18,Color.WHITE,Paint.Align.CENTER);
        }
        button(c,x+w*.70f,y+70,"บันทึก Preset");
        button(c,x+w*.70f,y+125,"โหลด Preset");
        button(c,x+w*.70f,y+180,"ลบ Preset");
        button(c,x+w*.70f,y+235,"เปลี่ยนชื่อ");
        button(c,x+w*.70f,y+305,"ส่งออก");
        button(c,x+w*.70f,y+360,"นำเข้า");
    }
    void button(Canvas c,float x,float y,String s){
        fill(c,0xFF1B252B,x,y,x+125,y+40,8); text(c,s,x+62,y+25,10,Color.WHITE,Paint.Align.CENTER);
    }
    void drawSettings(Canvas c,float x,float y,float w,float h){
        section(c,x,y,w,"SETTINGS");
        String[] a={"ภาษา (Language)","ความสว่าง","ธีม (Theme)","หน่วยระยะ (Distance Unit)","เสียงเตือน","Auto Read เมื่อเชื่อมต่อ","เวอร์ชันแอป","เกี่ยวกับ"};
        for(int i=0;i<a.length;i++){
            float yy=y+65+i*58;
            text(c,a[i],x+25,yy,12,0xFFCCCCCC,Paint.Align.LEFT);
            if(i==0) text(c,"ไทย (Thai)  ▾",x+w-30,yy,12,Color.WHITE,Paint.Align.RIGHT);
            else if(i==1) { line(c,x+w*.55f,yy-4,x+w*.88f,yy-4,0xFF00BFFF,4); fill(c,0xFFE9EDF2,x+w*.82f,yy-12,x+w*.85f,yy+4,8); text(c,"80%",x+w*.50f,yy,12,Color.WHITE,Paint.Align.RIGHT); }
            else if(i==2) text(c,"Dark     Blue     Purple",x+w-25,yy,11,Color.WHITE,Paint.Align.RIGHT);
            else if(i==3) text(c,"cm    inch",x+w-25,yy,11,Color.WHITE,Paint.Align.RIGHT);
            else if(i==6) text(c,"1.0.0",x+w-25,yy,11,0xFFAAAAAA,Paint.Align.RIGHT);
            else if(i==7) text(c,"›",x+w-25,yy,20,Color.WHITE,Paint.Align.RIGHT);
            else { fill(c,0xFF00BFFF,x+w-55,yy-12,x+w-25,yy+5,10); }
        }
        text(c,"Bluetooth protocol: transport layer พร้อมแล้ว\nหมายเหตุ: ต้องใส่ packet protocol ของบอร์ดจริงเพื่อเขียนค่าลง BP1048P4",x+25,y+550,11,0xFF999999,Paint.Align.LEFT);
    }
    void drawNav(Canvas c,float w,float h){
        fill(c,0xFF0F1418,0,h-72,w,h-8,16);
        float slot=w/pages.length;
        for(int i=0;i<pages.length;i++){
            text(c,pages[i],slot*i+slot/2,h-34,10,i==page?0xFF00BFFF:0xFFBBBBBB,Paint.Align.CENTER);
            if(i==page) line(c,slot*i+12,h-12,slot*(i+1)-12,h-12,0xFF00BFFF,3);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        float vw = getWidth(), vh = getHeight();
        final float BASE_W = 1280f, BASE_H = 720f;
        float scale = Math.min(vw / BASE_W, vh / BASE_H);
        float ox = (vw - BASE_W * scale) / 2f;
        float oy = (vh - BASE_H * scale) / 2f;

        float bx = (e.getX() - ox) / scale;
        float by = (e.getY() - oy) / scale;

        if(e.getAction()==MotionEvent.ACTION_DOWN){
            downX = bx;
            downY = by;
            return true;
        }
        if(e.getAction()==MotionEvent.ACTION_UP){
            float dx = bx - downX;

            if(Math.abs(dx) > 70){
                if(dx < 0 && page < pages.length-1) page++;
                else if(dx > 0 && page > 0) page--;
                invalidate();
                return true;
            }

            if(by > BASE_H-90){
                page = Math.max(0, Math.min(pages.length-1,
                        (int)(bx/(BASE_W/pages.length))));
                invalidate();
                return true;
            }

            if(page==0 && by>300 && by<570){
                int idx = (int)((bx-8)/((BASE_W-30)/7f));
                if(idx>=0 && idx<7){
                    mute[idx]=!mute[idx];
                    invalidate();
                }
            }
            return true;
        }
        return true;
    }
}
