package com.okn.golopinedsp;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;
import java.util.Arrays;

/** OEM crypto helpers. No key is hard-coded. */
public final class OemCrypto {
    private OemCrypto() {}
    public static byte[] aesGcmDecrypt(byte[] key, byte[] nonce, byte[] ciphertextAndTag, byte[] aad) throws GeneralSecurityException {
        if (key == null || (key.length != 16 && key.length != 24 && key.length != 32)) throw new GeneralSecurityException("AES key must be 16/24/32 bytes");
        if (nonce == null || nonce.length < 7 || nonce.length > 13) throw new GeneralSecurityException("GCM nonce must be 7..13 bytes for OEM candidate mode");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        if (aad != null) c.updateAAD(aad);
        return c.doFinal(ciphertextAndTag);
    }
    public static byte[] aesGcmEncrypt(byte[] key, byte[] nonce, byte[] plain, byte[] aad) throws GeneralSecurityException {
        if (key == null || (key.length != 16 && key.length != 24 && key.length != 32)) throw new GeneralSecurityException("AES key must be 16/24/32 bytes");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        if (aad != null) c.updateAAD(aad);
        return c.doFinal(plain);
    }
    public static byte[] copyOf(byte[] x) { return x == null ? null : Arrays.copyOf(x, x.length); }
}
