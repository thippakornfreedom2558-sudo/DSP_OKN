# BP1048P4 DSP 7CH Controller v1.2

เริ่มทำชุดแอปตามหน้าตา mockup ที่ให้มาแล้ว

สิ่งที่มีในรุ่นนี้
- Android landscape / dark UI
- MAIN: Master Volume + CH1–CH7 fader
- EQ: 15-band / 7 channels + graph
- CROSSOVER: HPF / LPF
- DELAY / TIME ALIGNMENT
- MIXER / ROUTING
- PRESET
- SETTINGS
- BLE scan/connect foundation สำหรับ BP1048 family
- GitHub Actions สำหรับสร้าง APK ด้วยมือถือ

หมายเหตุสำคัญ:
รุ่นนี้เป็น UI + BLE foundation ยังไม่ได้เดาคำสั่งเขียนค่า DSP ของ GoloPine firmware
เพราะการเดา command อาจทำให้ค่า DSP ผิดหรือเกิดเสียงกระชากได้

เป้าหมายขั้นถัดไปคือจับคู่ command จริงจาก GoloPine APK กับค่า EQ/Crossover/Delay/Volume
แล้วจึงเปิดการเขียนค่าจริงทีละฟังก์ชัน
