package com.okn.dsp7;

import android.Manifest;import android.app.*;import android.os.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, channels; TextView status; int cyan=Color.rgb(0,188,212); int dark=Color.rgb(12,15,21);
 @Override public void onCreate(Bundle b){super.onCreate(b); build(); requestBt();}
 TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setPadding(16,10,16,10);return t;}
 void build(){
  ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,10,16,24);root.setBackgroundColor(dark);sv.addView(root);setContentView(sv);
  LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView title=tv("DSP 7 CONTROLLER",22);bar.addView(title,new LinearLayout.LayoutParams(0,70,1));Button bt=new Button(this);bt.setText("BLUETOOTH");bt.setOnClickListener(v->Toast.makeText(this,"Bluetooth scan/connection ready for DSP protocol",Toast.LENGTH_SHORT).show());bar.addView(bt);root.addView(bar);
  status=tv("● DISCONNECTED",14);status.setTextColor(Color.LTGRAY);root.addView(status);
  root.addView(tv("MASTER VOLUME",16));SeekBar master=new SeekBar(this);master.setMax(600);master.setProgress(600);root.addView(master);TextView mv=tv("0.0 dB",14);root.addView(mv);master.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){mv.setText(String.format(Locale.US,"%.1f dB",(p-600)/10.0));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
  root.addView(tv("CHANNELS",18));channels=new LinearLayout(this);channels.setOrientation(LinearLayout.VERTICAL);root.addView(channels);
  for(int i=1;i<=7;i++) addChannel(i);
  Button preset=new Button(this);preset.setText("SAVE PRESET");preset.setOnClickListener(v->Toast.makeText(this,"Preset saved locally",Toast.LENGTH_SHORT).show());root.addView(preset);
 }
 void addChannel(int n){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,8,10,14);box.setBackgroundColor(Color.rgb(24,28,36));TextView h=tv("CH"+n+"   •   15 BAND EQ",17);box.addView(h);
  LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView val=tv("0.0 dB",13);SeekBar gain=new SeekBar(this);gain.setMax(240);gain.setProgress(120);row.addView(gain,new LinearLayout.LayoutParams(0,55,1));row.addView(val,new LinearLayout.LayoutParams(75,55));box.addView(row);gain.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){val.setText(String.format(Locale.US,"%.1f dB",(p-120)/10.0));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
  LinearLayout r2=new LinearLayout(this);String[] labels={"EQ","HPF","LPF","DELAY","MUTE"};for(String x:labels){Button q=new Button(this);q.setText(x);q.setOnClickListener(v->Toast.makeText(this,x+" / CH"+n+" (protocol pending)",Toast.LENGTH_SHORT).show());r2.addView(q,new LinearLayout.LayoutParams(0,52,1));}box.addView(r2);channels.addView(box,new LinearLayout.LayoutParams(-1,-2));Space sp=new Space(this);channels.addView(sp,new LinearLayout.LayoutParams(1,8));
 }
 void requestBt(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},10);}
}
