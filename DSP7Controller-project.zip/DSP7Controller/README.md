# DSP 7 Controller
Android controller UI for a 7-channel DSP/BP1048P4 project.

## Current build
- Master volume: -60.0 to 0.0 dB
- CH1–CH7 gain
- EQ / HPF / LPF / Delay / Mute UI
- Bluetooth permission scaffold
- Preset save button scaffold

The DSP transport/protocol is intentionally isolated as the next integration step; do not assume BLE or classic Bluetooth until the original APK's protocol is verified.

## Build on GitHub from a phone
Upload this project to a GitHub repository, then use Actions. The included workflow builds a debug APK.
