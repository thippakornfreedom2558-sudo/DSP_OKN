# BP1048P4 DSP BLE Logger — รุ่นทดสอบ

โปรเจกต์นี้เป็นขั้นตอนแรกสำหรับถอด protocol ของ GoloPine/BP1048P4
จาก APK ที่ผู้ใช้ส่งมา

สิ่งที่รุ่นนี้ทำ:
- Scan BLE
- เชื่อมต่ออุปกรณ์
- Discover Services / Characteristics
- แสดง UUID และ properties
- เปิด Notify ให้กับ service 40af0001/0002/0003 เมื่อรองรับ
- บันทึก RX / READ / WRITE เป็น HEX

UUID ที่ฝังไว้จาก APK:
- 40af0001-9479-43f6-ae95-c45fb2afb9d2
- 40af0002-9479-43f6-ae95-c45fb2afb9d2
- 40af0003-9479-43f6-ae95-c45fb2afb9d2

## วิธีสร้าง APK บน GitHub จากมือถือ
1. สร้าง repository ใหม่
2. แตก ZIP นี้แล้วอัปโหลดไฟล์ทั้งหมดขึ้น repository
3. เพิ่ม workflow ของ GitHub Actions ให้รัน `gradle assembleDebug`
4. APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

หมายเหตุ:
รุ่นนี้ตั้งใจเป็น "เครื่องมือเก็บหลักฐาน protocol" ยังไม่ส่งคำสั่ง DSP แบบเดาสุ่ม
เพื่อป้องกันการเขียนค่าผิดเข้า DSP

ขั้นต่อไปหลังได้ log:
- ระบุ characteristic ที่ใช้ TX/RX
- จับคู่ packet กับ Device Description/Auth
- ถอดคำสั่ง parameter
- ทำ protocol engine
- ต่อเข้าหน้า MAIN/EQ/CROSSOVER/DELAY/MIXER/PRESET
