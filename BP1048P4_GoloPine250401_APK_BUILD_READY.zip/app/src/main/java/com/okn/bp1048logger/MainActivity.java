package com.okn.bp1048logger;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final UUID S1 = UUID.fromString("40af0001-9479-43f6-ae95-c45fb2afb9d2");
    static final UUID S2 = UUID.fromString("40af0002-9479-43f6-ae95-c45fb2afb9d2");
    static final UUID S3 = UUID.fromString("40af0003-9479-43f6-ae95-c45fb2afb9d2");
    BluetoothAdapter adapter;
    BluetoothLeScanner scanner;
    BluetoothGatt gatt;
    ScanCallback activeScanCallback;
    LinearLayout log;
    TextView status;
    final Map<String,BluetoothGattCharacteristic> chars = new LinkedHashMap<>();
    final Handler h = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        BluetoothManager bm = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter = bm.getAdapter();
        requestPermissionsIfNeeded();
    }

    void buildUi() {
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24,18,24,18);
        main.setBackgroundColor(Color.rgb(5,9,11));

        TextView title = tv("BP1048P4 7CH DSP  •  BLE PACKET LOGGER", 22, Color.WHITE);
        main.addView(title, new LinearLayout.LayoutParams(-1,60));

        status = tv("DISCONNECTED", 17, Color.YELLOW);
        main.addView(status, new LinearLayout.LayoutParams(-1,55));

        LinearLayout buttons = new LinearLayout(this);
        Button scan = btn("SCAN");
        Button stop = btn("STOP");
        Button clear = btn("CLEAR LOG");
        buttons.addView(scan); buttons.addView(stop); buttons.addView(clear);
        main.addView(buttons, new LinearLayout.LayoutParams(-1,65));

        ScrollView sv = new ScrollView(this);
        log = new LinearLayout(this);
        log.setOrientation(LinearLayout.VERTICAL);
        sv.addView(log);
        main.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        scan.setOnClickListener(v -> startScan());
        stop.setOnClickListener(v -> stopScan());
        clear.setOnClickListener(v -> log.removeAllViews());

        setContentView(main);
    }

    TextView tv(String s,int size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(8,4,8,4); return t;
    }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }

    void requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 &&
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED ||
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT}, 10);
        }
    }

    void startScan(){
        if(adapter==null || !adapter.isEnabled()){ status.setText("Bluetooth OFF"); return; }
        chars.clear(); status.setText("SCANNING...");
        scanner=adapter.getBluetoothLeScanner();
        activeScanCallback = new ScanCallback(){
            @Override public void onScanResult(int type, ScanResult r){
                BluetoothDevice d=r.getDevice();
                String name=d.getName();
                if(name==null) name="(no name)";
                // Show likely DSP devices and anything whose name contains BP/DSP/Golo.
                if(name.toUpperCase().contains("BP1048") || name.toUpperCase().contains("BP1048P4") ||
                   name.toUpperCase().contains("DSP") || name.toUpperCase().contains("GOLO")) {
                    add("FOUND  "+name+"  "+d.getAddress()+"  RSSI="+r.getRssi(), Color.CYAN);
                    stopScan();
                    connect(d);
                }
            }
        };
        scanner.startScan(activeScanCallback);
        h.postDelayed(this::stopScan, 12000);
    }

    void stopScan(){
        try {
            if(scanner!=null && activeScanCallback!=null) scanner.stopScan(activeScanCallback);
        } catch(Exception ignored){}
        activeScanCallback=null;
        if(status.getText().toString().equals("SCANNING...")) status.setText("SCAN STOPPED");
    }

    void connect(BluetoothDevice d){
        status.setText("CONNECTING: "+d.getName());
        gatt=d.connectGatt(this,false,new BluetoothGattCallback(){
            @Override public void onConnectionStateChange(BluetoothGatt g,int st,int state){
                runOnUiThread(() -> {
                    if(state==BluetoothProfile.STATE_CONNECTED){
                        status.setText("CONNECTED: "+g.getDevice().getName());
                        add("BLE CONNECTED", Color.GREEN);
                        g.discoverServices();
                    } else {
                        status.setText("DISCONNECTED");
                        add("BLE DISCONNECTED state="+state, Color.YELLOW);
                    }
                });
            }
            @Override public void onServicesDiscovered(BluetoothGatt g,int st){
                runOnUiThread(() -> {
                    add("SERVICES DISCOVERED", Color.GREEN);
                    for(BluetoothGattService s:g.getServices()){
                        add("SERVICE "+s.getUuid(), Color.WHITE);
                        for(BluetoothGattCharacteristic c:s.getCharacteristics()){
                            String key=c.getUuid().toString();
                            chars.put(key,c);
                            int p=c.getProperties();
                            add("  CHAR "+key+" props="+props(p), Color.LTGRAY);
                            if(c.getService().getUuid().equals(S1)||c.getService().getUuid().equals(S2)||c.getService().getUuid().equals(S3))
                                enableNotify(g,c);
                        }
                    }
                });
            }
            @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){
                byte[] v=c.getValue();
                add("RX "+c.getUuid()+"  "+hex(v), Color.rgb(0,220,120));
            }
            @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int st){
                add("READ "+c.getUuid()+"  "+hex(c.getValue())+" status="+st, Color.WHITE);
            }
            @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int st){
                add("WRITE "+c.getUuid()+" status="+st+"  "+hex(c.getValue()), Color.rgb(255,180,0));
            }
        });
    }

    void enableNotify(BluetoothGatt g,BluetoothGattCharacteristic c){
        try {
            if((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0){
                g.setCharacteristicNotification(c,true);
                BluetoothGattDescriptor d=c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                if(d!=null){
                    d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    g.writeDescriptor(d);
                }
                add("NOTIFY ENABLED "+c.getUuid(), Color.MAGENTA);
            }
        } catch(Exception e){ add("NOTIFY ERROR "+e.getMessage(),Color.RED); }
    }

    String props(int p){
        String s="";
        if((p&2)!=0)s+="READ ";
        if((p&8)!=0)s+="WRITE ";
        if((p&4)!=0)s+="WRITE_NR ";
        if((p&16)!=0)s+="NOTIFY ";
        if((p&32)!=0)s+="INDICATE ";
        return s;
    }
    String hex(byte[] b){
        if(b==null)return "";
        StringBuilder s=new StringBuilder();
        for(byte x:b)s.append(String.format(Locale.US,"%02X ",x&255));
        return s.toString().trim();
    }
    void add(String s,int color){
        runOnUiThread(()->{
            TextView t=tv(s,13,color);
            log.addView(t,0);
        });
    }

    @Override protected void onDestroy(){
        try{ if(gatt!=null)gatt.close(); }catch(Exception ignored){}
        super.onDestroy();
    }
}
