package com.okn.golopinedsp;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity implements BleController.Listener {
    private TextView monitorLogView;

    private LinearLayout root, body, nav; private TextView status, deviceInfo, masterValue; private BleController ble;
    private final ArrayList<String> devices=new ArrayList<>(); private int page=0, selectedCh=0; private boolean connected=false;
    private final String[] ch={"CH1\nFront L","CH2\nFront R","CH3\nSUB","CH4\nRear L","CH5\nRear R","CH6\nAUX L","CH7\nAUX R"};
    private final float[][] gain=new float[7][15]; private final float[][] q=new float[7][15]; private final float[][] hz=new float[7][15]; private final float[] outGain={-2,-2,-5,-2,-2,-2,-2};
    private final float[] master={-60}; private final float[] hp={20,20,20,20,20,20,20}, lp={20000,20000,120,20000,20000,20000,20000};
    private final float[] delay={0,0,150,0,0,0,0}; private final boolean[] mute=new boolean[7]; private final int[] presetIndex={0};
    private android.content.SharedPreferences pref;
    private static final int CYAN=Color.rgb(0,190,245), BG=Color.rgb(8,11,15), CARD=Color.rgb(24,28,34), GRID=Color.rgb(55,62,72), MUTED=Color.rgb(165,172,182), BLUE=Color.rgb(55,135,245);
    private final String[] presets={"User 1","User 2","User 3","Rock","Pop","Jazz","Classic","Flat"};
    private final float[] eqFreq={31.5f,50,80,125,200,315,500,800,1250,2000,3150,5000,8000,12500,16000};

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} 
    TextView tv(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(size);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(8),dp(3),dp(8),dp(3));return v;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),GRID);return g;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(8),dp(6),dp(8),dp(6));l.setBackground(bg(CARD,12));return l;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setAllCaps(false);b.setPadding(dp(2),0,dp(2),0);b.setBackground(bg(Color.rgb(28,33,40),10));return b;}
    SeekBar seek(int max,int progress){SeekBar s=new SeekBar(this);s.setMax(max);s.setProgress(Math.max(0,Math.min(max,progress)));return s;}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(5,7,9));pref=getSharedPreferences("dsp",0);load();initUi();requestPerms();}
    void initUi(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout top=row();top.setPadding(dp(7),dp(6),dp(7),dp(3));
        LinearLayout dev=card();deviceInfo=tv("● BP1048P4 7CH DSP\n  BLE • ยังไม่ได้เชื่อมต่อ",11);deviceInfo.setTextColor(CYAN);dev.addView(deviceInfo);top.addView(dev,new LinearLayout.LayoutParams(0,dp(66),1));
        Button scan=btn("ค้นหา DSP");scan.setOnClickListener(v->ble.scan());top.addView(scan,new LinearLayout.LayoutParams(dp(112),dp(66)));Button monitor=btn("BLE MONITOR");monitor.setOnClickListener(v->{page=7;render();});top.addView(monitor,new LinearLayout.LayoutParams(dp(112),dp(66))); Button oem=btn("OEM PROTOCOL");oem.setOnClickListener(v->{page=8;render();});top.addView(oem,new LinearLayout.LayoutParams(dp(112),dp(66)));
        Button read=btn("อ่าน DSP");read.setOnClickListener(v->{if(ble!=null)ble.requestAll();});top.addView(read,new LinearLayout.LayoutParams(dp(105),dp(66)));
        Button save=btn("บันทึก DSP");save.setOnClickListener(v->{save();toast("บันทึกค่าภายในเครื่องแล้ว");});top.addView(save,new LinearLayout.LayoutParams(dp(105),dp(66)));root.addView(top);
        LinearLayout masterRow=row();masterRow.setPadding(dp(7),0,dp(7),dp(3));LinearLayout mc=card();mc.addView(tv("MASTER VOLUME",10));masterValue=tv("-60.0 dB",21);mc.addView(masterValue);
        SeekBar ms=seek(660,0);mc.addView(ms);ms.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){master[0]=-60+p*.1f;masterValue.setText(String.format(Locale.US,"%.1f dB",master[0]));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){save();}});masterRow.addView(mc,new LinearLayout.LayoutParams(0,dp(96),1));
        LinearLayout pc=card();pc.addView(tv("PRESET",10));Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,presets));sp.setSelection(presetIndex[0]);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){if(p!=presetIndex[0])applyPreset(p);}});pc.addView(sp);masterRow.addView(pc,new LinearLayout.LayoutParams(dp(135),dp(96)));root.addView(masterRow);
        status=tv("● พร้อม — กด ค้นหา DSP",10);status.setTextColor(CYAN);root.addView(status); 
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(3),dp(3),dp(3),dp(3));String[] tabs={"⌂\nMAIN","∿\nEQ","⌁\nCROSSOVER","◷\nDELAY","↔\nMIXER","☆\nPRESET","⚙\nSETTINGS"};for(int i=0;i<tabs.length;i++){final int p=i;Button btab=btn(tabs[i]);nav.addView(btab,new LinearLayout.LayoutParams(0,dp(58),1));btab.setOnClickListener(v->{page=p;render();});}root.addView(nav);ble=new BleController(this,this);setContentView(root);render();}

    void render(){body.removeAllViews();if(page==0)mainPage();else if(page==1)eqPage();else if(page==2)crossoverPage();else if(page==3)delayPage();else if(page==4)mixerPage();else if(page==5)presetPage();else if(page==7)body.addView(monitorPage(),new LinearLayout.LayoutParams(-1,0,1));else if(page==8)body.addView(oemProtocolPage(),new LinearLayout.LayoutParams(-1,0,1));else settingsPage();}
    TextView section(String s){TextView t=tv(s,18);t.setPadding(dp(12),dp(10),dp(8),dp(8));return t;}
    void mainPage(){
        body.addView(section("MAIN • 7 CHANNEL OUTPUT"));LinearLayout hs=row();HorizontalScrollView sc=new HorizontalScrollView(this);hs.setPadding(dp(7),0,dp(7),dp(8));
        for(int i=0;i<7;i++){final int c=i;LinearLayout box=card();box.setBackground(bg(i==2?Color.rgb(42,29,55):CARD,10));TextView title=tv(ch[i]+"\n"+String.format(Locale.US,"%.1f dB",outGain[i]),11);title.setGravity(Gravity.CENTER);box.addView(title);Fader f=new Fader(this);f.channel=c;f.value=outGain[i];box.addView(f,new LinearLayout.LayoutParams(dp(105),dp(170)));Button m=btn(mute[i]?"MUTED":"MUTE");m.setOnClickListener(v->{mute[c]=!mute[c];m.setText(mute[c]?"MUTED":"MUTE");save();});box.addView(m,new LinearLayout.LayoutParams(-1,dp(38)));box.setOnClickListener(v->{selectedCh=c;page=1;render();});hs.addView(box,new LinearLayout.LayoutParams(dp(130),dp(235)));}sc.addView(hs);body.addView(sc);
        LinearLayout quick=row();quick.setPadding(dp(7),0,dp(7),dp(7));quick.addView(actionCard("BASS","-4.0 dB",-12,12,8));quick.addView(actionCard("MIDDLE","0.0 dB",-12,12,12));quick.addView(actionCard("TREBLE","8.0 dB",-12,12,20));quick.addView(actionCard("SUB XOVER","120 Hz",20,250,100));body.addView(quick);
    }
    LinearLayout actionCard(String name,String initial,int min,int max,int val){LinearLayout c=card();c.addView(tv(name,10));TextView v=tv(initial,16);v.setGravity(Gravity.CENTER);c.addView(v);SeekBar s=seek(max-min,val-min);c.addView(s);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){float x=min+p;v.setText(name.contains("XOVER")?String.format(Locale.US,"%.0f Hz",x):String.format(Locale.US,"%.1f dB",x));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}});c.setPadding(dp(8),dp(5),dp(8),dp(5));c.setLayoutParams(new LinearLayout.LayoutParams(0,dp(92),1));return c;}

    void eqPage(){
        body.addView(section("EQ • 15 BAND PARAMETRIC"));LinearLayout chs=row();for(int i=0;i<7;i++){final int c=i;Button b=btn("CH"+(i+1));if(c==selectedCh)b.setTextColor(CYAN);b.setOnClickListener(v->{selectedCh=c;render();});chs.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));}body.addView(chs);
        EqGraph g=new EqGraph(this);body.addView(g,new LinearLayout.LayoutParams(-1,dp(230)));
        LinearLayout tool=row();tool.setPadding(dp(8),dp(5),dp(8),dp(5));Button flat=btn("FLAT");flat.setOnClickListener(v->{Arrays.fill(gain[selectedCh],0);render();});tool.addView(flat,new LinearLayout.LayoutParams(dp(85),dp(45)));Button copy=btn("COPY CH");copy.setOnClickListener(v->{System.arraycopy(gain[selectedCh],0,gain[0],0,15);toast("คัดลอก EQ ไป CH1");});tool.addView(copy,new LinearLayout.LayoutParams(dp(100),dp(45)));Button save=btn("SAVE EQ");save.setOnClickListener(v->{save();toast("บันทึก EQ");});tool.addView(save,new LinearLayout.LayoutParams(dp(100),dp(45)));body.addView(tool);
        for(int i=0;i<15;i++)eqRow(i);
        TextView note=tv("หมายเหตุ: ค่า EQ ในรุ่นนี้เก็บเป็น DSP profile ภายในแอปก่อน จนกว่าเราจะยืนยัน byte mapping ของ GoloPine firmware",10);note.setTextColor(MUTED);body.addView(note);
    }
    void eqRow(int band){LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);TextView n=tv("B"+(band+1)+"\n"+formatHz(eqFreq[band]),10);r.addView(n,new LinearLayout.LayoutParams(dp(75),dp(64)));SeekBar s=seek(240,(int)(120+gain[selectedCh][band]*10));TextView v=tv(String.format(Locale.US,"%+.1f dB",gain[selectedCh][band]),10);r.addView(s,new LinearLayout.LayoutParams(0,dp(58),1));r.addView(v,new LinearLayout.LayoutParams(dp(75),dp(58)));final int b=band;s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int p,boolean f){gain[selectedCh][b]=(p-120)/10f;v.setText(String.format(Locale.US,"%+.1f dB",gain[selectedCh][b]));}public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){save();}});body.addView(r);}
    String formatHz(float f){return f>=1000?String.format(Locale.US,"%.1fk",f/1000):String.format(Locale.US,"%.1f",f);}

    void crossoverPage(){body.addView(section("CROSSOVER • HPF / LPF / SLOPE"));for(int i=0;i<7;i++){final int c=i;LinearLayout box=card();box.addView(tv(ch[i],14));TextView h=tv("HPF  "+String.format(Locale.US,"%.0f Hz",hp[i]),11);box.addView(h);SeekBar hs=seek(480,Math.max(0,(int)hp[i]-20));box.addView(hs);hs.setOnSeekBarChangeListener(sl(h,20,500,"HPF",c));TextView l=tv("LPF  "+String.format(Locale.US,"%.0f Hz",lp[i]),11);box.addView(l);SeekBar ls=seek(19950,(int)lp[i]-50);box.addView(ls);ls.setOnSeekBarChangeListener(sl(l,50,20000,"LPF",c));LinearLayout slopes=row();for(String x:new String[]{"12","18","24","36","48"}){Button sb=btn(x+" dB/oct");sb.setOnClickListener(v->toast("Slope "+x+" dB/oct • CH"+(c+1)));slopes.addView(sb,new LinearLayout.LayoutParams(0,dp(42),1));}box.addView(slopes);body.addView(box);}}
    SeekBar.OnSeekBarChangeListener sl(TextView t,float min,float max,String label,int c){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){float x=min+p;t.setText(label+"  "+String.format(Locale.US,"%.0f Hz",x));if(label.equals("HPF"))hp[c]=x;else lp[c]=x;}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}};}

    void delayPage(){body.addView(section("DELAY • TIME ALIGNMENT"));body.addView(tv("ระยะลำโพงจากตำแหน่งผู้ฟัง • cm   |   1 ms ≈ 34.3 cm",11));for(int i=0;i<7;i++){final int c=i;LinearLayout box=card();TextView t=tv(ch[i]+"   "+String.format(Locale.US,"%.0f cm / %.2f ms",delay[i],delay[i]/34.3),13);box.addView(t);SeekBar s=seek(500,(int)delay[i]);box.addView(s);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){delay[c]=p;t.setText(ch[c]+"   "+String.format(Locale.US,"%.0f cm / %.2f ms",delay[c],delay[c]/34.3));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}});body.addView(box);}}
    void mixerPage(){body.addView(section("MIXER • INPUT → OUTPUT ROUTING"));body.addView(tv("L/R routing matrix • ค่า 0–100%",11));for(int i=0;i<7;i++){LinearLayout box=card();box.addView(tv(ch[i],13));box.addView(route("L",100));box.addView(route("R",100));body.addView(box);}}
    LinearLayout route(String n,int val){LinearLayout r=row();TextView t=tv(n+"   "+val+"%",12);r.addView(t,new LinearLayout.LayoutParams(dp(75),dp(45)));SeekBar s=seek(100,val);r.addView(s,new LinearLayout.LayoutParams(0,dp(45),1));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){t.setText(n+"   "+p+"%");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}});return r;}
    void presetPage(){body.addView(section("PRESET • USER / FACTORY"));for(int i=0;i<presets.length;i++){final int p=i;LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);TextView n=tv((i==presetIndex[0]?"● ":"○ ")+presets[i],14);r.addView(n,new LinearLayout.LayoutParams(0,dp(55),1));Button load=btn("โหลด");load.setOnClickListener(v->applyPreset(p));r.addView(load,new LinearLayout.LayoutParams(dp(80),dp(48)));Button save=btn("บันทึก");save.setOnClickListener(v->{presetIndex[0]=p;this.save();render();});r.addView(save,new LinearLayout.LayoutParams(dp(85),dp(48)));body.addView(r);}}
    private View oemProtocolPage() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.addView(section("BLE X-RAY • GoloPine APK EVIDENCE"));
        TextView intro = tv("ข้อมูลจาก APK GoloPine ที่ใช้เป็นหลักฐานอ้างอิง • ยังไม่สรุป byte mapping จนกว่าจะจับ RX จริง", 12);
        intro.setTextColor(MUTED);
        root.addView(intro);
        String[] facts = {
            "Framework: Flutter / libapp.so",
            "BLE Service: 0000AB00-0000-1000-8000-00805F9B34FB",
            "TX: 0000AB01-0000-1000-8000-00805F9B34FB",
            "RX: 0000AB02-0000-1000-8000-00805F9B34FB",
            "Additional UUID: 40AF0003-9479-43F6-AE95-C45FB2AFB9D2",
            "BLE strings: writeCharacteristic / readCharacteristic / setNotifyValue",
            "DSP strings: EqGraphicOnchange / Parse BiquadFilter / modify float32 Value",
            "Frame signature observed: A5 5A ... 16",
            "เป้าหมาย: Volume → CH1-CH7 → EQ → Crossover → Delay → Mixer"
        };
        for (String f : facts) { LinearLayout c = card(); c.addView(tv(f, 11)); root.addView(c); }
        LinearLayout r = row();
        Button fw = btn("FIRMWARE"); fw.setOnClickListener(v -> { if (ble != null) ble.requestFirmware(); });
        Button sys = btn("SYSTEM"); sys.setOnClickListener(v -> { if (ble != null) ble.write(DspProtocol.query(0x01)); });
        Button d0 = btn("DAC0"); d0.setOnClickListener(v -> { if (ble != null) ble.write(DspProtocol.query(0x09)); });
        Button d1 = btn("DAC1"); d1.setOnClickListener(v -> { if (ble != null) ble.write(DspProtocol.query(0x0A)); });
        r.addView(fw, new LinearLayout.LayoutParams(0, dp(50), 1));
        r.addView(sys, new LinearLayout.LayoutParams(0, dp(50), 1));
        r.addView(d0, new LinearLayout.LayoutParams(0, dp(50), 1));
        r.addView(d1, new LinearLayout.LayoutParams(0, dp(50), 1));
        root.addView(r);
        Button cap = btn("CAPTURE BLE X-RAY");
        cap.setOnClickListener(v -> { if (ble != null) ble.captureBleProtocol(); });
        root.addView(cap, new LinearLayout.LayoutParams(-1, dp(52)));
        return root;
    }

    void settingsPage(){body.addView(section("SETTINGS • SYSTEM / BLE / PROTOCOL"));String[] a={"รุ่น: BP1048P4 DSP PRO v2.3.4","อุปกรณ์: LE-GoloPine_DSP_A","Service: 0000AB00-0000-1000-8000-00805F9B34FB","TX: 0000AB01-0000-1000-8000-00805F9B34FB","RX: 0000AB02 / AB03","Protocol: A5 5A [control] [len] [payload] 16","App: BP1048P4 DSP PRO v2.3.4","ภาษา: ไทย / English","Theme: Dark Cyan"};for(String x:a){LinearLayout r=card();r.addView(tv(x,12));body.addView(r);}Button fw=btn("READ FIRMWARE");fw.setOnClickListener(v->ble.requestFirmware());body.addView(fw,new LinearLayout.LayoutParams(-1,dp(50)));Button all=btn("READ ALL DSP BLOCKS");all.setOnClickListener(v->ble.requestAll());body.addView(all,new LinearLayout.LayoutParams(-1,dp(50)));Button dis=btn("DISCONNECT");dis.setOnClickListener(v->ble.disconnect());body.addView(dis,new LinearLayout.LayoutParams(-1,dp(50)));}

    void applyPreset(int p){presetIndex[0]=p;Arrays.fill(gain[selectedCh],0);if(p==3){for(int i=0;i<15;i++)gain[selectedCh][i]=(i>8?2:0);}else if(p==4){for(int i=0;i<15;i++)gain[selectedCh][i]=(i<5?2:(i>10?3:0));}else if(p==5){for(int i=0;i<15;i++)gain[selectedCh][i]=(i<4?-1:(i>9?2:0));}else if(p==6){for(int i=0;i<15;i++)gain[selectedCh][i]=(i==3||i==9?2:0);}else if(p==7)Arrays.fill(gain[selectedCh],0);save();render();toast("โหลด "+presets[p]);}
    void load(){for(int c=0;c<7;c++)for(int b=0;b<15;b++){gain[c][b]=pref.getFloat("g"+c+"_"+b,0);q[c][b]=pref.getFloat("q"+c+"_"+b,.7f);hz[c][b]=pref.getFloat("h"+c+"_"+b,eqFreq[b]);}for(int i=0;i<7;i++){outGain[i]=pref.getFloat("o"+i,i==2?-5:-2);hp[i]=pref.getFloat("hp"+i,20);lp[i]=pref.getFloat("lp"+i,i==2?120:20000);delay[i]=pref.getFloat("d"+i,0);mute[i]=pref.getBoolean("m"+i,false);}master[0]=pref.getFloat("master",-60);presetIndex[0]=pref.getInt("preset",0);}
    void save(){android.content.SharedPreferences.Editor e=pref.edit();for(int c=0;c<7;c++)for(int b=0;b<15;b++){e.putFloat("g"+c+"_"+b,gain[c][b]);e.putFloat("q"+c+"_"+b,q[c][b]);e.putFloat("h"+c+"_"+b,hz[c][b]);}for(int i=0;i<7;i++){e.putFloat("o"+i,outGain[i]);e.putFloat("hp"+i,hp[i]);e.putFloat("lp"+i,lp[i]);e.putFloat("d"+i,delay[i]);e.putBoolean("m"+i,mute[i]);}e.putFloat("master",master[0]);e.putInt("preset",presetIndex[0]);e.apply();}

    class Fader extends View{Paint p=new Paint(1);float value=-2; int channel=0;Fader(Context c){super(c);}protected void onDraw(Canvas c){float cx=getWidth()/2f,top=dp(12),bot=getHeight()-dp(15);p.setStrokeWidth(dp(5));p.setColor(Color.rgb(70,77,88));c.drawLine(cx,top,cx,bot,p);float y=bot-(value+60)/66f*(bot-top);p.setColor(CYAN);c.drawLine(cx,y,cx,bot,p);p.setColor(Color.WHITE);c.drawRoundRect(cx-dp(15),y-dp(9),cx+dp(15),y+dp(9),dp(6),dp(6),p);p.setTextSize(dp(8));p.setTextAlign(Paint.Align.CENTER);p.setColor(MUTED);for(int d=-60;d<=0;d+=12){float yy=bot-(d+60)/66f*(bot-top);c.drawText(""+d,cx-dp(26),yy+dp(3),p);}}public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){float top=dp(12),bot=getHeight()-dp(15);value=Math.max(-60,Math.min(6,(bot-e.getY())/(bot-top)*66-60)); outGain[channel]=value; invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){save(); toast(String.format(Locale.US,"CH%d %.1f dB",channel+1,value));}return true;}}
    class EqGraph extends View{Paint p=new Paint(1);EqGraph(Context c){super(c);}protected void onDraw(Canvas c){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(12,16,21));c.drawRect(0,0,getWidth(),getHeight(),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(GRID);for(int i=0;i<=8;i++){float y=i*getHeight()/8f;c.drawLine(0,y,getWidth(),y,p);}for(int i=0;i<15;i++){float x=i*getWidth()/14f;c.drawLine(x,0,x,getHeight(),p);}p.setColor(CYAN);p.setStrokeWidth(dp(3));Path path=new Path();for(int i=0;i<15;i++){float x=i*getWidth()/14f;float y=getHeight()/2f-gain[selectedCh][i]*(getHeight()/28f);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);p.setTextSize(dp(9));p.setTextAlign(Paint.Align.CENTER);for(int i=0;i<15;i++){float x=i*getWidth()/14f;float y=getHeight()/2f-gain[selectedCh][i]*(getHeight()/28f);p.setColor(CYAN);c.drawCircle(x,y,dp(7),p);p.setColor(Color.BLACK);c.drawText(""+(i+1),x,y+dp(3),p);}p.setColor(MUTED);p.setTextAlign(Paint.Align.LEFT);c.drawText("+12 dB",dp(4),dp(12),p);c.drawText("0",dp(4),getHeight()/2f,p);c.drawText("-12 dB",dp(4),getHeight()-dp(5),p);}}

    void requestPerms(){ArrayList<String> p=new ArrayList<>();if(Build.VERSION.SDK_INT>=31){p.add(Manifest.permission.BLUETOOTH_SCAN);p.add(Manifest.permission.BLUETOOTH_CONNECT);}else if(Build.VERSION.SDK_INT>=23)p.add(Manifest.permission.ACCESS_FINE_LOCATION);if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),10);}
    @Override public void onDevice(String n,String a,int r){runOnUiThread(()->{String s=n+"  •  "+a+"  •  "+r+" dBm";if(!devices.contains(s))devices.add(s);deviceInfo.setText("● พบ DSP\n  "+n+"\n  "+a+"  "+r+" dBm");});}
    @Override public void onLog(String s){runOnUiThread(()->{status.setText("● "+s);showMonitorLog();});}
    @Override public void onState(String s){runOnUiThread(()->{status.setText("● "+s);if(s.contains("พร้อมใช้งาน")){connected=true;deviceInfo.setText("● BP1048P4 7CH DSP\n  LE-GoloPine_DSP_A\n  GATT READY");}});}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private View monitorPage() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));

        TextView title = tv("BLE MONITOR", 24);
        root.addView(title);

        TextView help = tv("ดูข้อมูล TX/RX จาก DSP • ใช้ตรวจสอบโปรโตคอลจริง", 14);
        root.addView(help);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button clear = new Button(this);
        clear.setText("ล้าง LOG");
        clear.setOnClickListener(v -> {
            if (ble != null) ble.clearLog();
            showMonitorLog();
        });

        Button test = new Button(this);
        test.setText("ส่ง READ TEST");
        test.setOnClickListener(v -> {
            if (ble != null) { ble.addLog("=== READ TEST PRESSED ==="); ble.requestFirmware(); }
            showMonitorLog();
        });

        Button capture = new Button(this);
        capture.setText("CAPTURE BLE");
        capture.setOnClickListener(v -> {
            if (ble != null) ble.captureBleProtocol();
            showMonitorLog();
        });

        row.addView(clear, new LinearLayout.LayoutParams(0, dp(52), 1));
        row.addView(test, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(row);
        root.addView(capture, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView log = new TextView(this);
        log.setTextColor(Color.WHITE);
        log.setTextSize(12);
        log.setGravity(Gravity.TOP | Gravity.START);
        log.setPadding(dp(10), dp(10), dp(10), dp(10));
        log.setTypeface(Typeface.MONOSPACE);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.rgb(18,20,25));
        sv.addView(log);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        monitorLogView = log;
        showMonitorLog();
        return root;
    }

    private void showMonitorLog() {
        if (monitorLogView == null) return;
        monitorLogView.setText(ble == null ? "BLE controller not ready" : ble.getLogText());
    }

}
