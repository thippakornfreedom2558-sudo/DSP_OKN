# GoloPine BP1048P4 7CH DSP Controller v1.0 UI

โปรเจกต์ Android แบบ Native Java สำหรับทำหน้าตาแอปควบคุม DSP 7 ช่องตาม mockup ที่ผู้ใช้ส่งมา

## หน้าจอ
- MAIN: Master + 7 Channel fader + Bass/Treble/Sub/Xover
- EQ: 15-band ต่อช่อง × 7 + กราฟ EQ
- CROSSOVER: HPF/LPF และ slope
- DELAY: ระยะ/Time alignment
- MIXER: L/R routing
- PRESET: User/Rock/Pop/Jazz/Classic/Flat
- SETTINGS
- BLE scanner และ layer สำหรับ BP1048 family ที่มีอยู่ในโปรเจกต์

## สำคัญ
UI และ BLE layer พร้อม แต่ mapping packet ของ GoloPine firmware ตัวจริงยังต้องยืนยันจาก traffic ของ APK/บอร์ดจริงก่อนจึงจะส่งค่า EQ/volume จริงได้ ป้องกันการส่ง packet ผิด firmware

## Build
อัปโหลดโฟลเดอร์นี้ขึ้น GitHub แล้วใช้ GitHub Actions workflow ใน `.github/workflows` เพื่อ build debug APK
