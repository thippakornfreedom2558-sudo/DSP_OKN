# BP1048P4 DSP 7CH — สร้าง APK จากมือถือ

ไฟล์นี้ทำไว้สำหรับผู้ใช้ที่ไม่มีคอมพิวเตอร์

## วิธีทำ APK บนมือถือด้วย GitHub
1. สร้าง Repository ใหม่บน GitHub
2. แตก ZIP นี้ แล้วอัปโหลด **ไฟล์และโฟลเดอร์ทั้งหมดใน ZIP ลง root ของ Repository**
3. เข้าแท็บ **Actions**
4. เลือก workflow **Build Android APK**
5. กด **Run workflow**
6. รอจนขึ้นสีเขียว
7. เข้า workflow ที่สร้างเสร็จ → ดาวน์โหลด Artifact ชื่อ `GoloPineBP1048P4-APK`
8. แตกไฟล์ ZIP ที่ดาวน์โหลด แล้วติดตั้ง `app-debug.apk` บนมือถือ

## หมายเหตุ
- แอปนี้เป็น UI/ฐานการเชื่อมต่อ BLE สำหรับ BP1048P4 7CH
- protocol ควบคุม DSP จริงต้องยืนยันกับ firmware ของบอร์ด GoloPine ก่อนใช้งาน EQ/Delay/Crossover แบบเต็ม
