package com.okn.golopinedsp;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity implements BleController.Listener {
    private LinearLayout root, body, nav; private TextView status, pageTitle; private BleController ble;
    private final int REQ=10; private int page=0, selectedCh=0;
    private final String[] ch={"CH1\nFront L","CH2\nFront R","CH3\nSUB","CH4\nRear L","CH5\nRear R","CH6\nAUX L","CH7\nAUX R"};
    private final float[][] gains=new float[7][15];
    private final float[] freqs={20,31.5f,50,80,125,200,315,500,800,1250,2000,3150,5000,8000,12500};
    private final int CYAN=Color.rgb(0,194,255), BG=Color.rgb(10,13,17), CARD=Color.rgb(24,28,34), MUTED=Color.rgb(150,158,170);

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} 
    TextView text(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(size);v.setPadding(dp(8),dp(6),dp(8),dp(6));return v;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));g.setStroke(dp(1),Color.rgb(50,57,67));return g;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(bg(Color.rgb(28,33,40),10));return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(7,9,12)); build(); requestPerms();}
    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout top=row();top.setPadding(dp(8),dp(8),dp(8),dp(4));
        LinearLayout device=card(); device.setPadding(dp(10),dp(5),dp(10),dp(5));
        TextView d=text("◉  CONNECTED\n    BP1048P4 7CH DSP",12);d.setTextColor(CYAN);device.addView(d,new LinearLayout.LayoutParams(dp(170),dp(62)));
        top.addView(device,new LinearLayout.LayoutParams(0,dp(70),1));
        Button scan=btn("ค้นหา DSP");top.addView(scan,new LinearLayout.LayoutParams(dp(110),dp(60)));scan.setOnClickListener(v->ble.scan());
        Button save=btn("💾 บันทึก DSP");top.addView(save,new LinearLayout.LayoutParams(dp(120),dp(60)));save.setOnClickListener(v->toast("บันทึกค่า DSP (UI) — protocol จะเชื่อมต่อเมื่อยืนยัน firmware"));
        root.addView(top);
        LinearLayout master=row();master.setPadding(dp(8),0,dp(8),dp(4));
        LinearLayout mbox=card();mbox.addView(text("MASTER VOLUME",11)); TextView mv=text("-12.5 dB",22);mv.setTextColor(Color.WHITE);mbox.addView(mv);SeekBar ms=new SeekBar(this);ms.setMax(600);ms.setProgress(475);mbox.addView(ms);ms.setOnSeekBarChangeListener(seekText(mv,-60,0,10));master.addView(mbox,new LinearLayout.LayoutParams(0,dp(96),1));
        LinearLayout pbox=card();pbox.addView(text("PRESET",11));Spinner sp=new Spinner(this);String[] ps={"User 1","User 2","Rock","Pop","Jazz","Flat"};sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ps));pbox.addView(sp);master.addView(pbox,new LinearLayout.LayoutParams(dp(130),dp(96)));root.addView(master);
        status=text("● พร้อม — เปิด Bluetooth แล้วกดค้นหา DSP",12);status.setTextColor(CYAN);status.setPadding(dp(14),0,dp(14),dp(4));root.addView(status);
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(5),dp(4),dp(5),dp(4));String[] tabs={"⌂\nMAIN","∿\nEQ","⌁\nCROSSOVER","◷\nDELAY","⚙\nMIXER","☆\nPRESET","⚙\nSETTINGS"};for(int i=0;i<tabs.length;i++){final int ii=i;Button btab=btn(tabs[i]);btab.setGravity(Gravity.CENTER);nav.addView(btab,new LinearLayout.LayoutParams(0,dp(58),1));btab.setOnClickListener(v->{page=ii;render();});}root.addView(nav);ble=new BleController(this,this);setContentView(root);render();
    }
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(8),dp(5),dp(8),dp(5));l.setBackground(bg(CARD,12));return l;}
    SeekBar.OnSeekBarChangeListener seekText(TextView t,float min,float max,float step){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){t.setText(String.format(Locale.US,"%.1f dB",min+p*step));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}};}
    void render(){body.removeAllViews(); if(page==0)mainPage();else if(page==1)eqPage();else if(page==2)crossoverPage();else if(page==3)delayPage();else if(page==4)mixerPage();else if(page==5)presetPage();else settingsPage();}
    void channelCards(){LinearLayout r=row();r.setPadding(dp(8),dp(4),dp(8),dp(8));for(int i=0;i<7;i++){final int c=i;LinearLayout box=card();box.setBackground(bg(c==2?Color.rgb(37,28,52):CARD,10));TextView t=text(ch[i]+"\n"+String.format(Locale.US,"%.1f dB",c==2?-5.0f:-2.0f),11);box.addView(t);SeekBar s=new SeekBar(this);s.setMax(600);s.setProgress(c==2?550:580);box.addView(s,new LinearLayout.LayoutParams(-1,dp(95)));Button mute=btn("Mute");box.addView(mute);r.addView(box,new LinearLayout.LayoutParams(0,dp(180),1));}body.addView(r);}
    void mainPage(){pageTitle=text("MAIN",18);body.addView(pageTitle);channelCards();LinearLayout tools=row();tools.setPadding(dp(8),dp(3),dp(8),dp(8));String[] n={"Bass\n0 dB","Treble\n0 dB","SUB VOL\n-5 dB","XOVER\n120 Hz"};for(String s:n){LinearLayout c=card();c.addView(text(s,14));SeekBar sb=new SeekBar(this);sb.setMax(24);sb.setProgress(12);c.addView(sb);tools.addView(c,new LinearLayout.LayoutParams(0,dp(80),1));}body.addView(tools);}
    void eqPage(){body.addView(text("EQ   15-Band Parametric EQ",18));LinearLayout chrow=row();for(int i=0;i<7;i++){final int c=i;Button b=btn("CH"+(i+1));if(i==selectedCh)b.setTextColor(CYAN);chrow.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));b.setOnClickListener(v->{selectedCh=c;render();});}body.addView(chrow);body.addView(new EqGraph(this));LinearLayout table=card();table.addView(text("Band     Frequency       Gain       Q",12));for(int i=0;i<15;i++){LinearLayout rr=row();rr.addView(text(String.valueOf(i+1),12),new LinearLayout.LayoutParams(dp(45),dp(44)));rr.addView(text(formatHz(freqs[i]),12),new LinearLayout.LayoutParams(dp(100),dp(44)));SeekBar g=new SeekBar(this);g.setMax(240);g.setProgress((int)(120+gains[selectedCh][i]*10));rr.addView(g,new LinearLayout.LayoutParams(0,dp(44),1));TextView val=text(String.format(Locale.US,"%.1f dB",gains[selectedCh][i]),11);rr.addView(val,new LinearLayout.LayoutParams(dp(65),dp(44)));final int band=i;g.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){gains[selectedCh][band]=(p-120)/10f;val.setText(String.format(Locale.US,"%.1f dB",gains[selectedCh][band]));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});table.addView(rr);}body.addView(table);}
    String formatHz(float f){return f>=1000?String.format(Locale.US,"%.1fk",f/1000):String.format(Locale.US,"%.1f",f);}
    void crossoverPage(){body.addView(text("CROSSOVER",18));for(int i=0;i<7;i++){LinearLayout c=card();c.addView(text(ch[i],13));c.addView(text("High Pass (HPF)",11));c.addView(sliderLine("Freq",20,500,80));c.addView(sliderLine("Slope",6,48,24));c.addView(text("Low Pass (LPF)",11));c.addView(sliderLine("Freq",50,20000,20000));body.addView(c);}}
    LinearLayout sliderLine(String n,int min,int max,int val){LinearLayout r=row();TextView t=text(n+"  "+val,11);r.addView(t,new LinearLayout.LayoutParams(dp(110),dp(45)));SeekBar s=new SeekBar(this);s.setMax(max-min);s.setProgress(val-min);r.addView(s,new LinearLayout.LayoutParams(0,dp(45),1));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){t.setText(n+"  "+(min+p));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});return r;}
    void delayPage(){body.addView(text("DELAY / TIME ALIGNMENT",18));body.addView(text("หน่วย: cm     ระยะอ้างอิงจากตำแหน่งผู้ฟัง",12));for(int i=0;i<7;i++){LinearLayout c=card();c.addView(text(ch[i]+"    "+(i==2?150:120)+" cm",13));c.addView(sliderLine("Distance",0,500, i==2?150:120));body.addView(c);}}
    void mixerPage(){body.addView(text("MIXER / ROUTING",18));for(int i=0;i<7;i++){LinearLayout c=card();c.addView(text(ch[i],13));c.addView(sliderLine("L",0,100,100));c.addView(sliderLine("R",0,100,100));body.addView(c);}}
    void presetPage(){body.addView(text("PRESET",18));String[] p={"User 1","User 2","User 3","Rock","Pop","Jazz","Classic","Flat"};for(String x:p){LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);r.addView(text("☆  "+x,14),new LinearLayout.LayoutParams(0,dp(52),1));Button load=btn("โหลด");r.addView(load,new LinearLayout.LayoutParams(dp(70),dp(48)));Button save=btn("บันทึก");r.addView(save,new LinearLayout.LayoutParams(dp(80),dp(48)));body.addView(r);}}
    void settingsPage(){body.addView(text("SETTINGS",18));String[] s={"ภาษา / Language     ไทย (Thai)","Theme                 Dark / Cyan","หน่วยระยะ              cm / inch","เสียงเตือนเมื่อเชื่อมต่อ     ON","Auto Read DSP          ON","Firmware / Protocol     BP1048P4","เกี่ยวกับแอป             v1.0 UI"};for(String x:s){LinearLayout r=card();r.addView(text(x,14));body.addView(r);}}
    class EqGraph extends View{Paint p=new Paint(1);public EqGraph(Context c){super(c);setMinimumHeight(dp(240));}protected void onDraw(Canvas c){super.onDraw(c);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(12,16,21));c.drawRoundRect(0,0,getWidth(),getHeight(),dp(12),dp(12),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(Color.rgb(45,52,62));for(int i=0;i<8;i++){float y=i*getHeight()/7f;c.drawLine(0,y,getWidth(),y,p);}for(int i=0;i<15;i++){float x=i*getWidth()/14f;c.drawLine(x,0,x,getHeight(),p);}p.setColor(CYAN);p.setStrokeWidth(dp(2));Path path=new Path();for(int i=0;i<15;i++){float x=i*getWidth()/14f;float gain=gains[selectedCh][i];float y=getHeight()/2f-gain*(getHeight()/26f);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);for(int i=0;i<15;i++){float x=i*getWidth()/14f;float y=getHeight()/2f-gains[selectedCh][i]*(getHeight()/26f);c.drawCircle(x,y,dp(8),p);p.setColor(Color.BLACK);p.setTextSize(dp(8));p.setTextAlign(Paint.Align.CENTER);c.drawText(String.valueOf(i+1),x,y+dp(3),p);p.setColor(CYAN);}p.setColor(Color.WHITE);p.setTextSize(dp(10));p.setTextAlign(Paint.Align.LEFT);c.drawText("+12",dp(6),dp(14),p);c.drawText("0",dp(6),getHeight()/2f, p);c.drawText("-12",dp(6),getHeight()-dp(6),p);}
    }
    void requestPerms(){ArrayList<String> p=new ArrayList<>();if(Build.VERSION.SDK_INT>=31){p.add(Manifest.permission.BLUETOOTH_SCAN);p.add(Manifest.permission.BLUETOOTH_CONNECT);}else if(Build.VERSION.SDK_INT>=23)p.add(Manifest.permission.ACCESS_FINE_LOCATION);if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),REQ);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onLog(String s){runOnUiThread(()->status.setText("● "+s));}
    @Override public void onState(String s){runOnUiThread(()->status.setText("● "+s));}
}
