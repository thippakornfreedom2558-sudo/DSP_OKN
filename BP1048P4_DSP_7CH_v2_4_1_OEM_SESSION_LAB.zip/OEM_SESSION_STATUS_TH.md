# v2.4.1 OEM SESSION LAB

รุ่นนี้ยึดข้อมูลจาก GoloPine 1Apr2026 และ HCI snoop ที่ผู้ใช้ส่งมา

ยืนยันแล้ว:
- BLE Service AB00
- TX AB01
- observed ATT Write Command handle 0x0006
- แอปเชื่อมต่อ BLE และอ่าน/notify GATT ได้

ยังล็อกการส่งพารามิเตอร์ DSP จาก MAIN/EQ/GAIN:
- HCI ที่จับได้มีชั้นข้อมูลที่ยังถอด session/auth ไม่ครบ
- APK มีหลักฐานของ authentication, ECDH, HMAC, SHA-256 และ AES/ChaCha20 primitives
- ไม่ฝังคีย์หรือส่ง packet ที่เดาเอง เพื่อป้องกันการเขียนค่าผิดไปยัง DSP

รุ่นนี้แก้ GitHub Actions ให้ build โปรเจกต์ root โดยตรง และแก้ MAIN ให้เลื่อน CH1-CH7 ได้ครบจอ
