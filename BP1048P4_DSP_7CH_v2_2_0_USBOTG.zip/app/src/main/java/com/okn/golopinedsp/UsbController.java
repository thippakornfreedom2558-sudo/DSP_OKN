package com.okn.golopinedsp;

import android.app.PendingIntent;
import android.content.*;
import android.hardware.usb.*;
import android.os.*;
import java.util.*;

/** Generic Android USB-OTG diagnostics for BP1048 boards.
 * It intentionally does not assume a serial/HID driver: it enumerates interfaces/endpoints
 * and can try the known BP1048 A5 5A protocol over a bulk/interrupt endpoint when available.
 */
public class UsbController {
    public interface Listener { void onUsbLog(String s); void onUsbState(String s); }
    private static final String ACTION_USB_PERMISSION="com.okn.golopinedsp.USB_PERMISSION";
    private final Context ctx; private final Listener listener; private final UsbManager manager;
    private UsbDevice device; private UsbDeviceConnection connection; private UsbInterface usbIf;
    private UsbEndpoint inEp,outEp; private volatile boolean reading=false; private Thread reader;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent intent){
            if(!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
            UsbDevice d=intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            boolean granted=intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false);
            if(granted && d!=null){ emit("USB PERMISSION GRANTED"); open(d); }
            else emit("USB PERMISSION DENIED");
        }
    };
    public UsbController(Context c,Listener l){ctx=c;listener=l;manager=(UsbManager)c.getSystemService(Context.USB_SERVICE);
        IntentFilter f=new IntentFilter(ACTION_USB_PERMISSION);
        if(Build.VERSION.SDK_INT>=33)ctx.registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else ctx.registerReceiver(receiver,f);
    }
    private void emit(String s){listener.onUsbLog(s);}
    public void scan(){
        if(manager==null){emit("USB manager unavailable");return;}
        HashMap<String,UsbDevice> list=manager.getDeviceList();
        emit("=== USB OTG SCAN: "+list.size()+" device(s) ===");
        if(list.isEmpty()){listener.onUsbState("ไม่พบ USB • ต่อ OTG แล้วกดสแกน");return;}
        for(UsbDevice d:list.values()) describe(d);
        UsbDevice pick=null;
        for(UsbDevice d:list.values()){String s=(d.getManufacturerName()+" "+d.getProductName()+" "+d.getDeviceName()).toUpperCase(Locale.US);if(s.contains("MVSILICON")||s.contains("BP1048")||s.contains("GOLOPINE")||s.contains("DSP")){pick=d;break;}}
        if(pick==null)pick=list.values().iterator().next(); request(pick);
    }
    private void describe(UsbDevice d){
        emit("USB DEVICE "+d.getDeviceName()+" VID=0x"+hex2(d.getVendorId())+" PID=0x"+hex2(d.getProductId())+
             " class=0x"+hex2(d.getDeviceClass())+" subclass=0x"+hex2(d.getDeviceSubclass()));
        if(Build.VERSION.SDK_INT>=21){String ser="?";try{ser=safe(d.getSerialNumber());}catch(Exception ignored){} emit("  manufacturer="+safe(d.getManufacturerName())+" product="+safe(d.getProductName())+" serial="+ser);}
        for(int i=0;i<d.getInterfaceCount();i++){
            UsbInterface in=d.getInterface(i);emit("  IF#"+i+" class=0x"+hex2(in.getInterfaceClass())+" sub=0x"+hex2(in.getInterfaceSubclass())+" proto=0x"+hex2(in.getInterfaceProtocol())+" eps="+in.getEndpointCount());
            for(int j=0;j<in.getEndpointCount();j++){UsbEndpoint e=in.getEndpoint(j);emit("    EP addr=0x"+hex2(e.getAddress())+" "+(e.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT")+" type="+typeName(e.getType())+" max="+e.getMaxPacketSize());}
        }
    }
    private String safe(String s){return s==null?"?":s;}
    private String hex2(int n){return String.format(Locale.US,"%02X",n&0xFF);}
    private String typeName(int t){if(t==UsbConstants.USB_ENDPOINT_XFER_BULK)return"BULK";if(t==UsbConstants.USB_ENDPOINT_XFER_INT)return"INTERRUPT";if(t==UsbConstants.USB_ENDPOINT_XFER_CONTROL)return"CONTROL";return"ISO/OTHER";}
    private void request(UsbDevice d){device=d;if(manager.hasPermission(d)){open(d);return;}Intent i=new Intent(ACTION_USB_PERMISSION).setPackage(ctx.getPackageName());PendingIntent pi=PendingIntent.getBroadcast(ctx,0,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));manager.requestPermission(d,pi);emit("USB REQUEST PERMISSION: "+d.getDeviceName());}
    private synchronized void open(UsbDevice d){
        close();device=d;connection=manager.openDevice(d);if(connection==null){emit("USB OPEN FAILED");listener.onUsbState("USB เปิดไม่ได้");return;}
        for(int i=0;i<d.getInterfaceCount();i++){UsbInterface in=d.getInterface(i);for(int j=0;j<in.getEndpointCount();j++){UsbEndpoint e=in.getEndpoint(j);if((e.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK||e.getType()==UsbConstants.USB_ENDPOINT_XFER_INT)&&e.getDirection()==UsbConstants.USB_DIR_OUT&&outEp==null) {outEp=e;}if((e.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK||e.getType()==UsbConstants.USB_ENDPOINT_XFER_INT)&&e.getDirection()==UsbConstants.USB_DIR_IN&&inEp==null) {inEp=e;}}if(usbIf==null && (outEp!=null||inEp!=null)) usbIf=in;}
        if(usbIf==null){emit("USB NO BULK/INTERRUPT INTERFACE");listener.onUsbState("USB พบแล้ว แต่ไม่มี data endpoint");return;}
        if(!connection.claimInterface(usbIf,true)){emit("USB CLAIM INTERFACE FAILED");listener.onUsbState("Claim USB interface ไม่สำเร็จ");return;}
        emit("USB OPEN OK IF#"+usbIf.getId()+" IN="+(inEp==null?"none":"0x"+hex2(inEp.getAddress()))+" OUT="+(outEp==null?"none":"0x"+hex2(outEp.getAddress())));
        listener.onUsbState("USB OTG READY • VID 0x"+hex2(d.getVendorId())+" PID 0x"+hex2(d.getProductId())); startReader();
    }
    private void startReader(){if(inEp==null||connection==null||reading)return;reading=true;reader=new Thread(()->{byte[] buf=new byte[Math.max(64,Math.min(4096,inEp.getMaxPacketSize()*8))];while(reading&&connection!=null){try{int n=connection.bulkTransfer(inEp,buf,buf.length,150);if(n>0){byte[] x=Arrays.copyOf(buf,n);emit("USB RX ["+n+"] "+DspProtocol.hex(x));for(byte[] f:DspProtocol.split(x))emit("USB FRAME control=0x"+String.format(Locale.US,"%02X",DspProtocol.control(f))+" raw="+DspProtocol.hex(f));}}catch(Exception e){if(reading)emit("USB RX ERROR: "+e.getMessage());}}});reader.start();}
    public synchronized boolean send(byte[] data){if(connection==null||outEp==null){emit("USB TX FAILED: no OUT endpoint");return false;}try{int n=connection.bulkTransfer(outEp,data,data.length,1000);emit("USB TX ["+data.length+"] "+DspProtocol.hex(data)+" -> n="+n);return n==data.length;}catch(Exception e){emit("USB TX ERROR: "+e.getMessage());return false;}}
    public void firmwareTest(){send(DspProtocol.firmwareInfoRequest());}
    public void runKnownTests(){main.post(()->{firmwareTest();main.postDelayed(()->send(DspProtocol.effectListQuery()),900);main.postDelayed(()->send(DspProtocol.query(0x01)),1800);main.postDelayed(()->send(DspProtocol.query(0x09)),2700);main.postDelayed(()->send(DspProtocol.query(0x0A)),3600);});}
    public boolean isReady(){return connection!=null&&outEp!=null;}
    public void close(){reading=false;if(connection!=null){try{if(usbIf!=null)connection.releaseInterface(usbIf);}catch(Exception ignored){}try{connection.close();}catch(Exception ignored){}}connection=null;usbIf=null;inEp=null;outEp=null;}
    public void destroy(){close();try{ctx.unregisterReceiver(receiver);}catch(Exception ignored){}}
}
