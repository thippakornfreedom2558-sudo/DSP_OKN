# แก้ Build GitHub Actions — v2.3.5

ปัญหาจากภาพ: GitHub รัน Gradle ใน `DSP_OKN/DSP_OKN` แต่โฟลเดอร์นั้นไม่มี `settings.gradle` จึงขึ้น `Directory ... does not contain a Gradle build`.

รุ่นนี้แก้ workflow ให้ค้นหา `settings.gradle` หรือ `settings.gradle.kts` อัตโนมัติ แล้ว `cd` เข้า Android project ก่อน build จึงรองรับทั้ง ZIP ที่แตกตรง root และ ZIP ที่มีโฟลเดอร์ซ้อน.

คำสั่ง build: `gradle :app:assembleDebug --no-daemon --stacktrace`

Artifact: `BP1048P4-DSP-7CH-v2.3.5-ACTUATOR-LAB-APK`
