package com.okn.golopinedsp;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity implements BleController.Listener {
    private LinearLayout root, body, nav;
    private TextView status, masterValue;
    private BleController ble; private TextView bleSeen; private final LinkedHashSet<String> seenDevices=new LinkedHashSet<>();
    private int page = 0, selectedCh = 0;
    private final String[] ch = {
        "CH1\nFront L","CH2\nFront R","CH3\nSUB","CH4\nRear L",
        "CH5\nRear R","CH6\nAUX L","CH7\nAUX R"
    };
    private final float[][] gains = new float[7][15];
    private final float[] freqs = {20,25,40,63,100,160,250,400,630,1000,1600,2500,4000,6300,16000};
    private static final int CYAN=Color.rgb(0,190,245), BG=Color.rgb(9,12,16),
            CARD=Color.rgb(24,28,34), GRID=Color.rgb(48,55,65), MUTED=Color.rgb(165,172,182);

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    TextView tv(String s,float size){
        TextView v=new TextView(this); v.setText(s); v.setTextColor(Color.WHITE); v.setTextSize(size);
        v.setPadding(dp(8),dp(4),dp(8),dp(4)); return v;
    }
    GradientDrawable bg(int color,float r){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r));
        g.setStroke(dp(1),GRID); return g;
    }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(8),dp(6),dp(8),dp(6)); l.setBackground(bg(CARD,12)); return l; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(11);
        b.setAllCaps(false); b.setBackground(bg(Color.rgb(28,33,40),10)); return b; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(5,7,9)); build(); requestPerms();
    }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout top=row(); top.setPadding(dp(8),dp(7),dp(8),dp(3));

        LinearLayout device=card();
        TextView d=tv("●  BP1048P4 7CH DSP\n      BLE controller • waiting for DSP",11);
        d.setTextColor(CYAN); device.addView(d);
        top.addView(device,new LinearLayout.LayoutParams(0,dp(62),1));

        Button scan=btn("ค้นหา DSP"); top.addView(scan,new LinearLayout.LayoutParams(dp(112),dp(62)));
        scan.setOnClickListener(v->ble.scan());

        Button save=btn("💾 บันทึก DSP"); top.addView(save,new LinearLayout.LayoutParams(dp(120),dp(62)));
        save.setOnClickListener(v->toast("UI พร้อมแล้ว • คำสั่งเขียนจริงจะผูกกับ protocol ของ GoloPine firmware"));
        root.addView(top);

        LinearLayout master=row(); master.setPadding(dp(8),0,dp(8),dp(3));
        LinearLayout m=card(); m.addView(tv("MASTER VOLUME",10));
        masterValue=tv("-12.5 dB",21); m.addView(masterValue);
        SeekBar ms=new SeekBar(this); ms.setMax(600); ms.setProgress(475); m.addView(ms);
        ms.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){
                float val=-60f+p*0.1f; masterValue.setText(String.format(Locale.US,"%.1f dB",val));
            }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        master.addView(m,new LinearLayout.LayoutParams(0,dp(94),1));

        LinearLayout pbox=card(); pbox.addView(tv("PRESET",10));
        Spinner sp=new Spinner(this);
        String[] ps={"User 1","User 2","User 3","Rock","Pop","Jazz","Classic","Flat"};
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ps));
        pbox.addView(sp); master.addView(pbox,new LinearLayout.LayoutParams(dp(135),dp(94)));
        root.addView(master);

        status=tv("● พร้อม — กด “ค้นหา DSP” เพื่อสแกน BLE",11);\n        bleSeen=tv("BLE: ยังไม่พบอุปกรณ์",10); bleSeen.setTextColor(MUTED);
        status.setTextColor(CYAN); root.addView(status); root.addView(bleSeen);

        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.addView(body);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        nav=row(); nav.setPadding(dp(4),dp(3),dp(4),dp(3));
        String[] tabs={"⌂\nMAIN","∿\nEQ","⌁\nCROSSOVER","◷\nDELAY","⚙\nMIXER","☆\nPRESET","⚙\nSETTINGS"};
        for(int i=0;i<tabs.length;i++){ final int ii=i; Button btab=btn(tabs[i]);
            btab.setGravity(Gravity.CENTER); nav.addView(btab,new LinearLayout.LayoutParams(0,dp(58),1));
            btab.setOnClickListener(v->{page=ii;render();});
        }
        root.addView(nav);
        ble=new BleController(this,this); setContentView(root); render();
    }

    void render(){
        body.removeAllViews();
        if(page==0) mainPage(); else if(page==1) eqPage(); else if(page==2) crossoverPage();
        else if(page==3) delayPage(); else if(page==4) mixerPage(); else if(page==5) presetPage(); else settingsPage();
    }

    void mainPage(){
        body.addView(tv("MAIN",18));
        LinearLayout r=row(); r.setPadding(dp(8),dp(3),dp(8),dp(8));
        for(int i=0;i<7;i++){
            final int c=i; LinearLayout box=card();
            box.setBackground(bg(c==2?Color.rgb(39,29,53):CARD,10));
            TextView t=tv(ch[i]+"\n"+String.format(Locale.US,"%.1f dB",c==2?-5f:-2f),11);
            t.setGravity(Gravity.CENTER); box.addView(t);
            VerticalFader f=new VerticalFader(this); f.setValue(c==2?-5f:-2f);
            box.addView(f,new LinearLayout.LayoutParams(-1,dp(118),1));
            Button mute=btn("Mute"); box.addView(mute,new LinearLayout.LayoutParams(-1,dp(38)));
            r.addView(box,new LinearLayout.LayoutParams(0,dp(215),1));
        }
        body.addView(r);
        LinearLayout tools=row(); tools.setPadding(dp(8),0,dp(8),dp(8));
        String[] n={"BASS\n0 dB","TREBLE\n0 dB","SUB VOL\n-5 dB","XOVER\n120 Hz"};
        for(String s:n){ LinearLayout c=card(); c.addView(tv(s,13)); SeekBar sb=new SeekBar(this);
            sb.setMax(240); sb.setProgress(120); c.addView(sb); tools.addView(c,new LinearLayout.LayoutParams(0,dp(75),1)); }
        body.addView(tools);
    }

    void eqPage(){
        body.addView(tv("EQ     15-BAND PARAMETRIC EQ",17));
        LinearLayout top=row();
        for(int i=0;i<7;i++){ final int c=i; Button b=btn("CH"+(i+1)+"\n"+ch[i].split("\n")[1]);
            if(i==selectedCh)b.setTextColor(CYAN); top.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));
            b.setOnClickListener(v->{selectedCh=c;render();});
        }
        body.addView(top);
        body.addView(new EqGraph(this),new LinearLayout.LayoutParams(-1,dp(250)));
        LinearLayout table=card();
        table.addView(tv("Band        Freq(Hz)        Gain(dB)        Q",11));
        for(int i=0;i<15;i++){
            LinearLayout rr=row(); rr.addView(tv(String.valueOf(i+1),11),new LinearLayout.LayoutParams(dp(45),dp(42)));
            rr.addView(tv(formatHz(freqs[i]),11),new LinearLayout.LayoutParams(dp(95),dp(42)));
            SeekBar g=new SeekBar(this); g.setMax(240); g.setProgress((int)(120+gains[selectedCh][i]*10));
            rr.addView(g,new LinearLayout.LayoutParams(0,dp(42),1));
            TextView val=tv(String.format(Locale.US,"%.1f",gains[selectedCh][i]),10);
            rr.addView(val,new LinearLayout.LayoutParams(dp(55),dp(42)));
            final int band=i;
            g.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar b,int p,boolean f){
                    gains[selectedCh][band]=(p-120)/10f;
                    val.setText(String.format(Locale.US,"%.1f",gains[selectedCh][band]));
                }
                public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
            });
            table.addView(rr);
        }
        body.addView(table);
    }

    String formatHz(float f){ return f>=1000?String.format(Locale.US,"%.1fk",f/1000):String.format(Locale.US,"%.0f",f); }

    void crossoverPage(){
        body.addView(tv("CROSSOVER",18));
        for(int i=0;i<7;i++){ LinearLayout c=card(); c.addView(tv(ch[i],13));
            c.addView(tv("High Pass (HPF)",11)); c.addView(sliderLine("Freq",20,500,80));
            c.addView(sliderLine("Slope",6,48,24)); c.addView(tv("Low Pass (LPF)",11));
            c.addView(sliderLine("Freq",50,20000,20000)); body.addView(c); }
    }

    LinearLayout sliderLine(String n,int min,int max,int val){
        LinearLayout r=row(); TextView t=tv(n+"  "+val,11); r.addView(t,new LinearLayout.LayoutParams(dp(115),dp(42)));
        SeekBar s=new SeekBar(this); s.setMax(max-min); s.setProgress(Math.max(0,Math.min(max-min,val-min)));
        r.addView(s,new LinearLayout.LayoutParams(0,dp(42),1));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){t.setText(n+"  "+(min+p));}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        }); return r;
    }

    void delayPage(){
        body.addView(tv("DELAY / TIME ALIGNMENT",18));
        body.addView(tv("หน่วย: cm     ระยะอ้างอิงจากตำแหน่งผู้ฟัง",11));
        for(int i=0;i<7;i++){ LinearLayout c=card(); c.addView(tv(ch[i],13));
            c.addView(sliderLine("Distance",0,500,i==2?150:120)); body.addView(c); }
    }

    void mixerPage(){
        body.addView(tv("MIXER / ROUTING",18));
        for(int i=0;i<7;i++){ LinearLayout c=card(); c.addView(tv(ch[i],13));
            c.addView(sliderLine("L",0,100,100)); c.addView(sliderLine("R",0,100,100)); body.addView(c); }
    }

    void presetPage(){
        body.addView(tv("PRESET",18));
        String[] p={"User 1","User 2","User 3","Rock","Pop","Jazz","Classic","Flat"};
        for(String x:p){ LinearLayout r=card(); r.setOrientation(LinearLayout.HORIZONTAL);
            r.addView(tv("☆  "+x,14),new LinearLayout.LayoutParams(0,dp(50),1));
            r.addView(btn("โหลด"),new LinearLayout.LayoutParams(dp(70),dp(46)));
            r.addView(btn("บันทึก"),new LinearLayout.LayoutParams(dp(80),dp(46)));
            body.addView(r);
        }
    }

    void settingsPage(){
        body.addView(tv("SETTINGS",18));
        String[] s={"ภาษา / Language        ไทย (Thai)","Theme                    Dark / Cyan",
                "หน่วยระยะ                 cm / inch","เสียงเตือนเมื่อเชื่อมต่อ     ON",
                "Auto Read DSP             ON","Firmware / Protocol       BP1048P4",
                "เกี่ยวกับแอป                v1.2 UI", "สถานะ protocol             BLE foundation ready"};
        for(String x:s){ LinearLayout r=card(); r.addView(tv(x,13)); body.addView(r); }
    }

    class VerticalFader extends View {
        Paint p=new Paint(1); float value=-2;
        VerticalFader(Context c){super(c);setMinimumWidth(dp(55));}
        void setValue(float v){value=Math.max(-60,Math.min(6,v));invalidate();}
        protected void onDraw(Canvas c){
            super.onDraw(c); float cx=getWidth()/2f, top=dp(12), bot=getHeight()-dp(10);
            p.setStrokeWidth(dp(3)); p.setColor(Color.rgb(75,82,92)); c.drawLine(cx,top,cx,bot,p);
            p.setStrokeWidth(dp(4)); p.setColor(CYAN);
            float y=bot-(value+60)/66f*(bot-top); c.drawLine(cx,y, cx,bot,p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
            c.drawRoundRect(cx-dp(10),y-dp(7),cx+dp(10),y+dp(7),dp(5),dp(5),p);
            p.setColor(MUTED); p.setTextSize(dp(8)); p.setTextAlign(Paint.Align.CENTER);
            for(int db=-60;db<=6;db+=12){float yy=bot-(db+60)/66f*(bot-top); c.drawText(String.valueOf(db),cx-dp(22),yy+dp(3),p);}
        }
        public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){
                float top=dp(12),bot=getHeight()-dp(10);
                float f=Math.max(0,Math.min(1,(bot-e.getY())/(bot-top)));
                value=f*66-60; invalidate(); return true;
            } return true;
        }
    }

    class EqGraph extends View {
        Paint p=new Paint(1);
        EqGraph(Context c){super(c);}
        protected void onDraw(Canvas c){
            super.onDraw(c); p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(12,16,21));
            c.drawRect(0,0,getWidth(),getHeight(),p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(GRID);
            for(int i=0;i<7;i++){float y=i*getHeight()/6f;c.drawLine(0,y,getWidth(),y,p);}
            for(int i=0;i<15;i++){float x=i*getWidth()/14f;c.drawLine(x,0,x,getHeight(),p);}
            p.setColor(CYAN);p.setStrokeWidth(dp(2));Path path=new Path();
            for(int i=0;i<15;i++){float x=i*getWidth()/14f;float y=getHeight()/2f-gains[selectedCh][i]*(getHeight()/28f);
                if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}
            c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
            for(int i=0;i<15;i++){float x=i*getWidth()/14f;float y=getHeight()/2f-gains[selectedCh][i]*(getHeight()/28f);
                c.drawCircle(x,y,dp(8),p); p.setColor(Color.BLACK);p.setTextSize(dp(8));p.setTextAlign(Paint.Align.CENTER);
                c.drawText(String.valueOf(i+1),x,y+dp(3),p);p.setColor(CYAN);}
            p.setColor(MUTED);p.setTextSize(dp(10));p.setTextAlign(Paint.Align.LEFT);
            c.drawText("+12",dp(5),dp(14),p);c.drawText("0",dp(5),getHeight()/2f,p);c.drawText("-12",dp(5),getHeight()-dp(5),p);
        }
    }

    void requestPerms(){
        ArrayList<String> p=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=31){p.add(Manifest.permission.BLUETOOTH_SCAN);p.add(Manifest.permission.BLUETOOTH_CONNECT);}
        else if(Build.VERSION.SDK_INT>=23)p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),10);
    }
    @Override public void onDevice(String name,String address){
        runOnUiThread(()->{
            String key=name+"  "+address;
            if(seenDevices.add(key) && seenDevices.size()<=8){
                bleSeen.setText("BLE พบ: "+name+"\n"+address+"\nกดค้นหาอีกครั้งเพื่อสแกนใหม่");
            }
        });
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onLog(String s){runOnUiThread(()->status.setText("● "+s));}
    @Override public void onState(String s){runOnUiThread(()->status.setText("● "+s));}
}
