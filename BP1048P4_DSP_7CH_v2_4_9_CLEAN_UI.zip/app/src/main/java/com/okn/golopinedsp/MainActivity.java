package com.okn.golopinedsp;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.database.ContentObserver;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.net.Uri;
import java.io.InputStream;
import java.util.*;

public class MainActivity extends Activity implements BleController.Listener {
    private TextView monitorLogView;
    private TextView hciOutput;
    private TextView diffOutput;
    private Uri diffBeforeUri, diffAfterUri;
    private Uri chBeforeUri, chAfterUri;
    private TextView chDiffOutput;

    private LinearLayout root, body, nav; private TextView status, deviceInfo, masterValue; private BleController ble;
    private final ArrayList<String> devices=new ArrayList<>(); private int page=0, selectedCh=0; private boolean connected=false;
    private final String[] ch={"CH1\nFront L","CH2\nFront R","CH3\nSUB","CH4\nRear L","CH5\nRear R","CH6\nAUX L","CH7\nAUX R"};
    private final float[][] gain=new float[7][15]; private final float[][] q=new float[7][15]; private final float[][] hz=new float[7][15]; private final float[] outGain={-2,-2,-5,-2,-2,-2,-2};
    private final float[] master={-60}; private final float[] hp={20,20,20,20,20,20,20}, lp={20000,20000,120,20000,20000,20000,20000};
    private final float[] delay={0,0,150,0,0,0,0}; private final boolean[] mute=new boolean[7]; private final int[] presetIndex={0};
    private android.content.SharedPreferences pref;
    private AudioManager audioManager;
    private ContentObserver volumeObserver;
    private int lastMusicVolume=-1;
    private static final int CYAN=Color.rgb(0,190,245), BG=Color.rgb(8,11,15), CARD=Color.rgb(24,28,34), GRID=Color.rgb(55,62,72), MUTED=Color.rgb(165,172,182), BLUE=Color.rgb(55,135,245);
    private final String[] presets={"User 1","User 2","User 3","Rock","Pop","Jazz","Classic","Flat"};
    private final float[] eqFreq={31.5f,50,80,125,200,315,500,800,1250,2000,3150,5000,8000,12500,16000};

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} 
    TextView tv(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(size);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(8),dp(3),dp(8),dp(3));return v;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),GRID);return g;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(8),dp(6),dp(8),dp(6));l.setBackground(bg(CARD,12));return l;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setAllCaps(false);b.setPadding(dp(2),0,dp(2),0);b.setBackground(bg(Color.rgb(28,33,40),10));return b;}
    SeekBar seek(int max,int progress){SeekBar s=new SeekBar(this);s.setMax(max);s.setProgress(Math.max(0,Math.min(max,progress)));return s;}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(5,7,9));pref=getSharedPreferences("dsp",0);load();initUi();requestPerms();}
    void initUi(){
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        lastMusicVolume=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout top=row();top.setPadding(dp(7),dp(6),dp(7),dp(3));
        LinearLayout dev=card();deviceInfo=tv("● BP1048P4 7CH DSP\n  BLE • ยังไม่ได้เชื่อมต่อ",11);deviceInfo.setTextColor(CYAN);dev.addView(deviceInfo);top.addView(dev,new LinearLayout.LayoutParams(0,dp(66),1));
        Button scan=btn("ค้นหา DSP");scan.setOnClickListener(v->ble.scan());top.addView(scan,new LinearLayout.LayoutParams(dp(112),dp(66)));
        Button save=btn("บันทึก DSP");save.setOnClickListener(v->{save();toast("บันทึกค่าภายในเครื่องแล้ว");});top.addView(save,new LinearLayout.LayoutParams(dp(105),dp(66)));root.addView(top);
        LinearLayout masterRow=row();masterRow.setPadding(dp(7),0,dp(7),dp(3));LinearLayout mc=card();mc.addView(tv("MASTER VOLUME",10));masterValue=tv("-60.0 dB",21);mc.addView(masterValue);
        SeekBar ms=seek(660,0);ms.setProgress(Math.max(0,Math.min(660,Math.round((master[0]+60f)*10f))));mc.addView(ms);
        TextView link=tv("MASTER → Android/Bluetooth Volume  •  ON",10);link.setTextColor(CYAN);mc.addView(link);
        ms.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
public void onProgressChanged(SeekBar s,int p,boolean f){
    master[0]=-60+p*.1f;
    masterValue.setText(String.format(Locale.US,"%.1f dB",master[0]));
    if(f&&audioManager!=null) setAndroidMasterFromDb(master[0]);
}
public void onStartTrackingTouch(SeekBar s){}
public void onStopTrackingTouch(SeekBar s){
    if(audioManager!=null) syncMasterSliderToAndroid();
    pref.edit().putBoolean("master_android_link",true).apply();save();
    if(ble!=null)ble.addLog(String.format(Locale.US,"UI MASTER %.1f dB | AndroidLink=true | DSP WRITE NOT VERIFIED",master[0]));
}});
        pref.edit().putBoolean("master_android_link",true).apply();masterRow.addView(mc,new LinearLayout.LayoutParams(0,dp(110),1));
        LinearLayout pc=card();pc.addView(tv("PRESET",10));Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,presets));sp.setSelection(presetIndex[0]);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){if(p!=presetIndex[0])applyPreset(p);}});pc.addView(sp);masterRow.addView(pc,new LinearLayout.LayoutParams(dp(135),dp(96)));root.addView(masterRow);
        status=tv("● พร้อม — กด ค้นหา DSP",10);status.setTextColor(CYAN);root.addView(status);
        
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(3),dp(3),dp(3),dp(3));String[] tabs={"⌂\nMAIN","∿\nEQ","⌁\nCROSSOVER","◷\nDELAY","↔\nMIXER","☆\nPRESET","⚙\nSETTINGS"};for(int i=0;i<tabs.length;i++){final int p=i;Button btab=btn(tabs[i]);nav.addView(btab,new LinearLayout.LayoutParams(0,dp(58),1));btab.setOnClickListener(v->{page=p;render();});}root.addView(nav);ble=new BleController(this,this);setContentView(root);render();}

    private void setAndroidMasterFromDb(float db){
        if(audioManager==null) return;
        int max=audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        if(max<=0) return;
        int target=Math.max(0,Math.min(max,Math.round(((db+60f)/66f)*max)));
        int current=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        if(current!=target){
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,target,0);
            // Some Bluetooth/Samsung routes apply volume asynchronously; nudge with the
            // same Android API used by the working volume buttons if setStreamVolume is ignored.
            int after=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            if(after!=target){
                int delta=target-after;
                int dir=delta>0?AudioManager.ADJUST_RAISE:AudioManager.ADJUST_LOWER;
                int n=Math.min(Math.abs(delta),max+1);
                for(int i=0;i<n;i++) audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,dir,0);
            }
        }
    }

    private void syncMasterSliderToAndroid(){
        if(audioManager==null) return;
        int max=audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int now=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        if(max>0){
            float db=-60f+(66f*now/max);
            master[0]=Math.max(-60f,Math.min(6f,db));
            masterValue.setText(String.format(Locale.US,"%.1f dB",master[0]));
        }
    }

    void render(){body.removeAllViews();if(page==0)mainPage();else if(page==1)eqPage();else if(page==2)crossoverPage();else if(page==3)delayPage();else if(page==4)mixerPage();else if(page==5)presetPage();else if(page==7)body.addView(monitorPage(),new LinearLayout.LayoutParams(-1,0,1));else if(page==8)body.addView(oemProtocolPage(),new LinearLayout.LayoutParams(-1,0,1));else if(page==9)body.addView(actuatorLabPage(),new LinearLayout.LayoutParams(-1,0,1));else if(page==10)body.addView(volumeProbePage(),new LinearLayout.LayoutParams(-1,0,1));else if(page==11)body.addView(hciAnalyzerPage(),new LinearLayout.LayoutParams(-1,0,1));else if(page==12)body.addView(masterPacketLabPage(),new LinearLayout.LayoutParams(-1,0,1));else if(page==13)body.addView(channelPacketLabPage(),new LinearLayout.LayoutParams(-1,0,1));else settingsPage();}
    TextView section(String s){TextView t=tv(s,18);t.setPadding(dp(12),dp(10),dp(8),dp(8));return t;}
    void mainPage(){
        body.addView(section("MAIN • 7 CHANNEL OUTPUT"));LinearLayout hs=row();HorizontalScrollView sc=new HorizontalScrollView(this);hs.setPadding(dp(7),0,dp(7),dp(8));
        for(int i=0;i<7;i++){final int c=i;LinearLayout box=card();box.setBackground(bg(i==2?Color.rgb(42,29,55):CARD,10));TextView title=tv(ch[i]+"\n"+String.format(Locale.US,"%.1f dB",outGain[i]),11);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
            Fader f=new Fader(this);f.channel=c;f.value=outGain[i];f.titleView=title;box.addView(f,new LinearLayout.LayoutParams(dp(105),dp(118)));
            LinearLayout ar=row(); ar.setPadding(dp(2),0,dp(2),0); Button minus=btn("−  1 dB"); Button plus=btn("+  1 dB");
            minus.setOnClickListener(v->{setChannelGain(c,outGain[c]-1f);f.value=outGain[c];f.invalidate();title.setText(ch[c]+"\n"+String.format(Locale.US,"%.1f dB",outGain[c]));});
            plus.setOnClickListener(v->{setChannelGain(c,outGain[c]+1f);f.value=outGain[c];f.invalidate();title.setText(ch[c]+"\n"+String.format(Locale.US,"%.1f dB",outGain[c]));});
            ar.addView(minus,new LinearLayout.LayoutParams(0,dp(42),1)); ar.addView(plus,new LinearLayout.LayoutParams(0,dp(42),1)); box.addView(ar);
            Button m=btn(mute[i]?"MUTED":"MUTE");m.setOnClickListener(v->{mute[c]=!mute[c];m.setText(mute[c]?"MUTED":"MUTE");save();});box.addView(m,new LinearLayout.LayoutParams(-1,dp(38)));
            hs.addView(box,new LinearLayout.LayoutParams(dp(140),dp(255)));
        }sc.addView(hs);body.addView(sc,new LinearLayout.LayoutParams(-1,dp(270)));
        LinearLayout quick=row();quick.setPadding(dp(7),0,dp(7),dp(7));quick.addView(actionCard("BASS","-4.0 dB",-12,12,8));quick.addView(actionCard("MIDDLE","0.0 dB",-12,12,12));quick.addView(actionCard("TREBLE","8.0 dB",-12,12,20));quick.addView(actionCard("SUB XOVER","120 Hz",20,250,100));body.addView(quick);
    }
    LinearLayout actionCard(String name,String initial,int min,int max,int val){LinearLayout c=card();c.addView(tv(name,10));TextView v=tv(initial,16);v.setGravity(Gravity.CENTER);c.addView(v);SeekBar s=seek(max-min,val-min);c.addView(s);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){float x=min+p;v.setText(name.contains("XOVER")?String.format(Locale.US,"%.0f Hz",x):String.format(Locale.US,"%.1f dB",x));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}});c.setPadding(dp(8),dp(5),dp(8),dp(5));c.setLayoutParams(new LinearLayout.LayoutParams(0,dp(92),1));return c;}

    void eqPage(){
        body.addView(section("EQ • 15 BAND PARAMETRIC"));LinearLayout chs=row();for(int i=0;i<7;i++){final int c=i;Button b=btn("CH"+(i+1));if(c==selectedCh)b.setTextColor(CYAN);b.setOnClickListener(v->{selectedCh=c;render();});chs.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));}body.addView(chs);
        EqGraph g=new EqGraph(this);body.addView(g,new LinearLayout.LayoutParams(-1,dp(230)));
        LinearLayout tool=row();tool.setPadding(dp(8),dp(5),dp(8),dp(5));Button flat=btn("FLAT");flat.setOnClickListener(v->{Arrays.fill(gain[selectedCh],0);render();});tool.addView(flat,new LinearLayout.LayoutParams(dp(85),dp(45)));Button copy=btn("COPY CH");copy.setOnClickListener(v->{System.arraycopy(gain[selectedCh],0,gain[0],0,15);toast("คัดลอก EQ ไป CH1");});tool.addView(copy,new LinearLayout.LayoutParams(dp(100),dp(45)));Button save=btn("SAVE EQ");save.setOnClickListener(v->{save();toast("บันทึก EQ");});tool.addView(save,new LinearLayout.LayoutParams(dp(100),dp(45)));body.addView(tool);
        for(int i=0;i<15;i++)eqRow(i);
        TextView note=tv("หมายเหตุ: ค่า EQ/GAIN ในรุ่นนี้เก็บเป็น DSP profile ภายในแอปก่อน จนกว่าเราจะยืนยัน OEM session + byte mapping ของ GoloPine firmware",10);note.setTextColor(MUTED);body.addView(note);
    }
    void eqRow(int band){LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);TextView n=tv("B"+(band+1)+"\n"+formatHz(eqFreq[band]),10);r.addView(n,new LinearLayout.LayoutParams(dp(75),dp(64)));SeekBar s=seek(240,(int)(120+gain[selectedCh][band]*10));TextView v=tv(String.format(Locale.US,"%+.1f dB",gain[selectedCh][band]),10);r.addView(s,new LinearLayout.LayoutParams(0,dp(58),1));r.addView(v,new LinearLayout.LayoutParams(dp(75),dp(58)));final int b=band;s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int p,boolean f){gain[selectedCh][b]=(p-120)/10f;v.setText(String.format(Locale.US,"%+.1f dB",gain[selectedCh][b]));}public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){save();}});body.addView(r);}
    String formatHz(float f){return f>=1000?String.format(Locale.US,"%.1fk",f/1000):String.format(Locale.US,"%.1f",f);}

    void crossoverPage(){body.addView(section("CROSSOVER • HPF / LPF / SLOPE"));for(int i=0;i<7;i++){final int c=i;LinearLayout box=card();box.addView(tv(ch[i],14));TextView h=tv("HPF  "+String.format(Locale.US,"%.0f Hz",hp[i]),11);box.addView(h);SeekBar hs=seek(480,Math.max(0,(int)hp[i]-20));box.addView(hs);hs.setOnSeekBarChangeListener(sl(h,20,500,"HPF",c));TextView l=tv("LPF  "+String.format(Locale.US,"%.0f Hz",lp[i]),11);box.addView(l);SeekBar ls=seek(19950,(int)lp[i]-50);box.addView(ls);ls.setOnSeekBarChangeListener(sl(l,50,20000,"LPF",c));LinearLayout slopes=row();for(String x:new String[]{"12","18","24","36","48"}){Button sb=btn(x+" dB/oct");sb.setOnClickListener(v->toast("Slope "+x+" dB/oct • CH"+(c+1)));slopes.addView(sb,new LinearLayout.LayoutParams(0,dp(42),1));}box.addView(slopes);body.addView(box);}}
    SeekBar.OnSeekBarChangeListener sl(TextView t,float min,float max,String label,int c){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){float x=min+p;t.setText(label+"  "+String.format(Locale.US,"%.0f Hz",x));if(label.equals("HPF"))hp[c]=x;else lp[c]=x;}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}};}

    void delayPage(){body.addView(section("DELAY • TIME ALIGNMENT"));body.addView(tv("ระยะลำโพงจากตำแหน่งผู้ฟัง • cm   |   1 ms ≈ 34.3 cm",11));for(int i=0;i<7;i++){final int c=i;LinearLayout box=card();TextView t=tv(ch[i]+"   "+String.format(Locale.US,"%.0f cm / %.2f ms",delay[i],delay[i]/34.3),13);box.addView(t);SeekBar s=seek(500,(int)delay[i]);box.addView(s);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){delay[c]=p;t.setText(ch[c]+"   "+String.format(Locale.US,"%.0f cm / %.2f ms",delay[c],delay[c]/34.3));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}});body.addView(box);}}
    void mixerPage(){body.addView(section("MIXER • INPUT → OUTPUT ROUTING"));body.addView(tv("L/R routing matrix • ค่า 0–100%",11));for(int i=0;i<7;i++){LinearLayout box=card();box.addView(tv(ch[i],13));box.addView(route("L",100));box.addView(route("R",100));body.addView(box);}}
    LinearLayout route(String n,int val){LinearLayout r=row();TextView t=tv(n+"   "+val+"%",12);r.addView(t,new LinearLayout.LayoutParams(dp(75),dp(45)));SeekBar s=seek(100,val);r.addView(s,new LinearLayout.LayoutParams(0,dp(45),1));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){t.setText(n+"   "+p+"%");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){save();}});return r;}
    void presetPage(){body.addView(section("PRESET • USER / FACTORY"));for(int i=0;i<presets.length;i++){final int p=i;LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);TextView n=tv((i==presetIndex[0]?"● ":"○ ")+presets[i],14);r.addView(n,new LinearLayout.LayoutParams(0,dp(55),1));Button load=btn("โหลด");load.setOnClickListener(v->applyPreset(p));r.addView(load,new LinearLayout.LayoutParams(dp(80),dp(48)));Button save=btn("บันทึก");save.setOnClickListener(v->{presetIndex[0]=p;this.save();render();});r.addView(save,new LinearLayout.LayoutParams(dp(85),dp(48)));body.addView(r);}}
    private View oemProtocolPage() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.addView(section("BLE X-RAY • GoloPine APK EVIDENCE"));
        TextView intro = tv("ข้อมูลจาก APK GoloPine ที่ใช้เป็นหลักฐานอ้างอิง • ยังไม่สรุป byte mapping จนกว่าจะจับ RX จริง", 12);
        intro.setTextColor(MUTED);
        root.addView(intro);
        TextView oemStatus = tv(OemProtocol.describe() + "\nCrypto engine: READY (key/session not hard-coded)", 10); oemStatus.setTextColor(CYAN); root.addView(oemStatus);
        String[] facts = {
            "Framework: Flutter / libapp.so",
            "BLE Service: 0000AB00-0000-1000-8000-00805F9B34FB",
            "TX: 0000AB01-0000-1000-8000-00805F9B34FB",
            "RX: 0000AB02-0000-1000-8000-00805F9B34FB",
            "Additional UUID: 40AF0003-9479-43F6-AE95-C45FB2AFB9D2",
            "BLE strings: writeCharacteristic / readCharacteristic / setNotifyValue",
            "DSP strings: EqGraphicOnchange / Parse BiquadFilter / modify float32 Value",
            "Frame signature observed: A5 5A ... 16",
            "เป้าหมาย: Volume → CH1-CH7 → EQ → Crossover → Delay → Mixer"
        };
        for (String f : facts) { LinearLayout c = card(); c.addView(tv(f, 11)); root.addView(c); }
        LinearLayout r = row();
        Button fw = btn("FIRMWARE"); fw.setOnClickListener(v -> { if (ble != null) ble.requestFirmware(); });
        Button sys = btn("SYSTEM"); sys.setOnClickListener(v -> { if (ble != null) ble.write(DspProtocol.query(0x01)); });
        Button d0 = btn("DAC0"); d0.setOnClickListener(v -> { if (ble != null) ble.write(DspProtocol.query(0x09)); });
        Button d1 = btn("DAC1"); d1.setOnClickListener(v -> { if (ble != null) ble.write(DspProtocol.query(0x0A)); });
        r.addView(fw, new LinearLayout.LayoutParams(0, dp(50), 1));
        r.addView(sys, new LinearLayout.LayoutParams(0, dp(50), 1));
        r.addView(d0, new LinearLayout.LayoutParams(0, dp(50), 1));
        r.addView(d1, new LinearLayout.LayoutParams(0, dp(50), 1));
        root.addView(r);
        Button cap = btn("CAPTURE BLE X-RAY");
        cap.setOnClickListener(v -> { if (ble != null) ble.captureBleProtocol(); });
        root.addView(cap, new LinearLayout.LayoutParams(-1, dp(52)));
        return root;
    }

    private View actuatorLabPage() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.addView(section("ACTUATOR LAB • MASTER VOLUME • TX TEST"));
        TextView note = tv("โหมดแกะโปรโตคอล • ค่าด้านล่างคำนวณ FLOAT32 จริง แต่ยังไม่ใช่ packet GoloPine ที่ยืนยันแล้ว", 12);
        note.setTextColor(MUTED); root.addView(note);
        final SeekBar v = seek(760, 0);
        final TextView val = tv("Master Volume = -70.0 dB", 18); root.addView(val); root.addView(v);
        final TextView hex = tv(floatHex(-70f), 13); hex.setTypeface(android.graphics.Typeface.MONOSPACE); root.addView(cardWith(hex));
        v.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean from){ float db=-70f+p*0.1f; val.setText(String.format(Locale.US,"Master Volume = %.1f dB",db)); hex.setText(floatHex(db)); }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        LinearLayout r=row();
        for(final float db:new float[]{-70f,-60f,-50f,-40f,-30f,0f,6f}){
            Button b=btn(String.format(Locale.US,"%.0f dB",db));
            b.setOnClickListener(x->{v.setProgress(Math.round((db+70f)*10f)); if(ble!=null) ble.addLog("LAB VALUE "+String.format(Locale.US,"%.1f dB",db)+" | "+floatHex(db).replace('\n',' '));});
            r.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));
        }
        root.addView(r);

        Button log=btn("บันทึกค่าเข้า BLE LOG (ไม่ส่ง DSP)");
        log.setOnClickListener(x->{if(ble!=null)ble.addLog("=== ACTUATOR LAB SNAPSHOT ===\n"+hex.getText().toString());});
        root.addView(log,new LinearLayout.LayoutParams(-1,dp(50)));

        final TextView txState = tv("TX ล่าสุด: ยังไม่มีการส่ง", 12);
        txState.setTextColor(CYAN);
        root.addView(cardWith(txState));

        Button raw=btn("⚠ TEST TX: ส่ง FLOAT32 4 ไบต์ดิบไป AB01");
        raw.setOnClickListener(x->{
            final float db=-70f+v.getProgress()*0.1f;
            new AlertDialog.Builder(this).setTitle("ยืนยันการส่งข้อมูลทดลอง")
                .setMessage(String.format(Locale.US,"จะส่ง FLOAT32 LE ของ %.1f dB ไป AB01\nยังไม่ใช่ packet GoloPine ที่ยืนยันแล้ว",db))
                .setNegativeButton("ยกเลิก",null)
                .setPositiveButton("ส่งทดสอบ",(d,w)->{
                    if(ble!=null){
                        byte[] b=floatBytesLE(db);
                        String hx=DspProtocol.hex(b);
                        ble.addLog("=== ACTUATOR RAW TX ===");
                        ble.addLog(String.format(Locale.US,"MASTER=%.1f dB | FLOAT32 LE=%s",db,hx));
                        ble.write(b);
                        txState.setText(String.format(Locale.US,"TX ล่าสุด: %.1f dB → %s",db,hx));
                    }
                }).show();
        });
        root.addView(raw,new LinearLayout.LayoutParams(-1,dp(52)));

        Button vp=btn("VOLUME PROBE • ANDROID + / −");
        vp.setOnClickListener(x->{page=10;render();});
        root.addView(vp,new LinearLayout.LayoutParams(-1,dp(52)));

        LinearLayout txRow=row();
        Button seq=btn("TX SEQUENCE -60/-50/-40");
        seq.setOnClickListener(x->{
            if(ble==null){return;}
            float[] vals={-60f,-50f,-40f};
            for(int i=0;i<vals.length;i++){
                final float db=vals[i];
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{
                    byte[] b=floatBytesLE(db); String hx=DspProtocol.hex(b);
                    ble.addLog(String.format(Locale.US,"=== ACTUATOR SEQ TX MASTER=%.1f dB LE=%s ===",db,hx));
                    ble.write(b);
                    txState.setText(String.format(Locale.US,"TX ล่าสุด: %.1f dB → %s",db,hx));
                },i*1800L);
            }
        });
        txRow.addView(seq,new LinearLayout.LayoutParams(0,dp(50),1));
        Button mon=btn("เปิด BLE MONITOR");
        mon.setOnClickListener(x->{page=7;render();});
        txRow.addView(mon,new LinearLayout.LayoutParams(0,dp(50),1));
        root.addView(txRow);

        TextView evidence=tv("สิ่งที่เราต้องการจากการทดสอบนี้:\n1) ค่า FLOAT32 ต้องเปลี่ยนตาม -60 / -50 / -40 จริง\n2) ดู BLE MONITOR ว่ามี TX และ RX หรือไม่\n3) ถ้า RAW FLOAT32 ไม่ทำให้ DSP เปลี่ยน แสดงว่า GoloPine ต้องมี header/ID/encoding เพิ่มเติม\n\nหลักฐาน APK 1Apr2026: UFE_TYPE_FLOAT32 • modify float32 Value = • WriteActuatorPeripheralCommand • Read Actuator sent ID= • writeCharacteristic",12);
        root.addView(cardWith(evidence));
        return root;
    }
    private View volumeProbePage() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(10),dp(14),dp(10));
        root.addView(section("VOLUME PROBE • ANDROID EVENT / DSP SEPARATION"));
        TextView note=tv("หน้านี้ไม่ส่ง packet DSP และไม่ดัก BLE ของแอปอื่น • ใช้แยกเหตุการณ์ Android Media Volume ออกจาก DSP Actuator",12);
        note.setTextColor(MUTED); root.addView(note);

        final TextView cur=tv("Android Media Volume = ?",20); cur.setTextColor(CYAN); root.addView(cardWith(cur));
        final TextView maxv=tv("",11); maxv.setTextColor(MUTED); root.addView(maxv);
        updateVolumeProbeLabels(cur,maxv);

        LinearLayout r=row();
        Button down=btn("−  VOLUME DOWN");
        down.setOnClickListener(v->{
            int before=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI);
            int after=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            logVolumeEvent("APP_VOLUME_DOWN",before,after);
            updateVolumeProbeLabels(cur,maxv);
        });
        Button up=btn("＋  VOLUME UP");
        up.setOnClickListener(v->{
            int before=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI);
            int after=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            logVolumeEvent("APP_VOLUME_UP",before,after);
            updateVolumeProbeLabels(cur,maxv);
        });
        r.addView(down,new LinearLayout.LayoutParams(0,dp(54),1));
        r.addView(up,new LinearLayout.LayoutParams(0,dp(54),1));
        root.addView(r);

        Button muteBtn=btn("MUTE / UNMUTE • ANDROID MEDIA");
        muteBtn.setOnClickListener(v->{
            int before=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            if(Build.VERSION.SDK_INT>=23) audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_TOGGLE_MUTE,AudioManager.FLAG_SHOW_UI);
            int after=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            logVolumeEvent("APP_VOLUME_MUTE_TOGGLE",before,after);
            updateVolumeProbeLabels(cur,maxv);
        });
        root.addView(muteBtn,new LinearLayout.LayoutParams(-1,dp(52)));

        Button clear=btn("ล้าง VOLUME PROBE LOG");
        clear.setOnClickListener(v->{if(ble!=null)ble.clearLog();});
        root.addView(clear,new LinearLayout.LayoutParams(-1,dp(48)));

        TextView instructions=tv("วิธีใช้เพื่อเทียบกับแอปผู้ผลิต:\n1) เปิด BLE MONITOR ของแอปเราไว้\n2) ใช้แอปผู้ผลิตกด + / − แล้วสังเกตว่า Android แสดงแถบเสียง\n3) แอปเราไม่สามารถอ่าน packet BLE ของแอปผู้ผลิตได้โดยตรง\n4) หากต้องการ packet จริง ต้องใช้ HCI snoop หรือวิเคราะห์ APK/firmware ต่อ\n\nเหตุการณ์ที่หน้านี้บันทึกได้: เวลา, Android Media Volume ก่อน/หลัง และสถานะ DSP connection",12);
        root.addView(cardWith(instructions));
        return root;
    }
    private void updateVolumeProbeLabels(TextView cur,TextView maxv){
        if(audioManager==null)return;
        int v=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC), m=audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        cur.setText("Android Media Volume = "+v+" / "+m);
        maxv.setText("STREAM_MUSIC • เปลี่ยนค่านี้จะไม่ส่งคำสั่ง DSP โดยอัตโนมัติ");
    }
    private void logVolumeEvent(String name,int before,int after){
        lastMusicVolume=after;
        if(ble!=null)ble.addLog(String.format(Locale.US,"VOLUME EVENT %s | Android Media %d → %d | DSP packet: NOT SENT",name,before,after));
    }
    private void startVolumeObserver(){
        if(volumeObserver!=null)return;
        volumeObserver=new ContentObserver(new Handler(Looper.getMainLooper())){
            @Override public void onChange(boolean selfChange, Uri uri){
                int now=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                if(now!=lastMusicVolume){
                    int before=lastMusicVolume; lastMusicVolume=now;
                    if(ble!=null)ble.addLog("ANDROID VOLUME CHANGED | "+before+" -> "+now+" | URI="+(uri==null?"":uri.toString()));
                }
            }
        };
        try{getContentResolver().registerContentObserver(Settings.System.CONTENT_URI,true,volumeObserver);}catch(Exception ignored){}
    }
    @Override protected void onResume(){super.onResume(); if(audioManager==null)audioManager=(AudioManager)getSystemService(AUDIO_SERVICE); lastMusicVolume=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC); startVolumeObserver();}
    @Override protected void onPause(){super.onPause();}

    private byte[] floatBytesLE(float f){ int bits=Float.floatToIntBits(f); return new byte[]{(byte)(bits&255),(byte)((bits>>>8)&255),(byte)((bits>>>16)&255),(byte)((bits>>>24)&255)}; }
    private LinearLayout cardWith(TextView t){ LinearLayout c=card(); c.addView(t); return c; }
    private String floatHex(float f){ int bits=Float.floatToIntBits(f); return String.format(Locale.US,"FLOAT32 LE: %02X %02X %02X %02X\nFLOAT32 BE: %02X %02X %02X %02X",bits&255,(bits>>>8)&255,(bits>>>16)&255,(bits>>>24)&255,(bits>>>24)&255,(bits>>>16)&255,(bits>>>8)&255,bits&255); }

    void settingsPage(){body.addView(section("SETTINGS • SYSTEM / BLE / PROTOCOL"));String[] a={"รุ่น: BP1048P4 DSP PRO v2.4.4","อุปกรณ์: LE-GoloPine_DSP_A","Service: 0000AB00-0000-1000-8000-00805F9B34FB","TX: 0000AB01-0000-1000-8000-00805F9B34FB","RX: 0000AB02 / AB03","Protocol: BLE actuator protocol — กำลังแกะ packet จริง; A5 5A เป็น USB candidate","App: BP1048P4 DSP PRO v2.4.4","ภาษา: ไทย / English","Theme: Dark Cyan"};for(String x:a){LinearLayout r=card();r.addView(tv(x,12));body.addView(r);}Button fw=btn("READ FIRMWARE");fw.setOnClickListener(v->ble.requestFirmware());body.addView(fw,new LinearLayout.LayoutParams(-1,dp(50)));Button all=btn("READ ALL DSP BLOCKS");all.setOnClickListener(v->ble.requestAll());body.addView(all,new LinearLayout.LayoutParams(-1,dp(50)));Button dis=btn("DISCONNECT");dis.setOnClickListener(v->ble.disconnect());body.addView(dis,new LinearLayout.LayoutParams(-1,dp(50)));}

    void applyPreset(int p){presetIndex[0]=p;Arrays.fill(gain[selectedCh],0);if(p==3){for(int i=0;i<15;i++)gain[selectedCh][i]=(i>8?2:0);}else if(p==4){for(int i=0;i<15;i++)gain[selectedCh][i]=(i<5?2:(i>10?3:0));}else if(p==5){for(int i=0;i<15;i++)gain[selectedCh][i]=(i<4?-1:(i>9?2:0));}else if(p==6){for(int i=0;i<15;i++)gain[selectedCh][i]=(i==3||i==9?2:0);}else if(p==7)Arrays.fill(gain[selectedCh],0);save();render();toast("โหลด "+presets[p]);}

    private View hciAnalyzerPage(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(14),dp(10),dp(14),dp(10));
        r.addView(section("HCI ANALYZER • BLE WRITE CAPTURE"));
        TextView note=tv("เลือกไฟล์ btsnoop_hci*.cfa หรือ btsnoop_hci.log จากโทรศัพท์เพื่อดูคำสั่ง BLE ที่แอปส่งจริง • หน้านี้อ่านอย่างเดียว ไม่ส่ง packet",12); note.setTextColor(MUTED); r.addView(note);
        Button open=btn("เลือกไฟล์ HCI"); r.addView(open,new LinearLayout.LayoutParams(-1,dp(52)));
        final TextView summary=tv("ยังไม่ได้เลือกไฟล์",12); summary.setTextColor(CYAN); r.addView(cardWith(summary));
        hciOutput=tv("",10); hciOutput.setTypeface(android.graphics.Typeface.MONOSPACE); ScrollView sv=new ScrollView(this); sv.addView(hciOutput); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        open.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i,441);});
        return r;
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data); if(res!=RESULT_OK||data==null||data.getData()==null)return; Uri u=data.getData(); if(req==451){diffBeforeUri=u;if(diffOutput!=null)diffOutput.setText("BEFORE selected: "+u+"\n");return;} if(req==452){diffAfterUri=u;if(diffOutput!=null)diffOutput.setText("AFTER selected: "+u+"\n");return;} if(req==461){chBeforeUri=u;if(chDiffOutput!=null)chDiffOutput.setText("BEFORE selected: "+u+"\n");return;} if(req==462){chAfterUri=u;if(chDiffOutput!=null)chDiffOutput.setText("AFTER selected: "+u+"\n");return;} if(req!=441)return; try(InputStream in=getContentResolver().openInputStream(u)){java.util.List<HciCaptureParser.Write> ws=HciCaptureParser.parse(in); int ab=0,special=0; StringBuilder x=new StringBuilder(); x.append("FILE: ").append(u).append("\nWRITES: ").append(ws.size()).append("\n\n"); for(HciCaptureParser.Write w:ws){if(w.handle==0x0006){ab++; if(w.data.length>=13)special++; x.append(String.format(Locale.US,"#%d  ATT=%02X  HANDLE=0x%04X  LEN=%d  DATA=%s\n",w.packetIndex,w.attOpcode,w.handle,w.data.length,HciCaptureParser.hex(w.data)));}} x.append("\nAB01/0x0006 writes: ").append(ab).append("\n13+ byte writes: ").append(special).append("\n"); if(hciOutput!=null)hciOutput.setText(x.toString()); if(ble!=null)ble.addLog("HCI ANALYZER: "+ab+" writes to handle 0x0006"); }catch(Exception e){if(hciOutput!=null)hciOutput.setText("อ่านไฟล์ไม่สำเร็จ: "+e.getMessage());}}

    private View channelPacketLabPage(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(14),dp(10),dp(14),dp(10));
        r.addView(section("CHANNEL PACKET LAB • CH1–CH7"));
        TextView note=tv("ใช้จับคำสั่งจริงของ GoloPine สำหรับ Gain/Mute รายช่อง โดยเทียบ HCI BEFORE/AFTER หลังเปลี่ยนเพียง 1 ช่อง • อ่านอย่างเดียว ไม่ส่ง packet เดา",12); note.setTextColor(MUTED); r.addView(note);
        LinearLayout chs=row(); for(int i=0;i<7;i++){ final int c=i; Button b=btn("CH"+(i+1)); if(c==selectedCh)b.setTextColor(CYAN); b.setOnClickListener(v->{selectedCh=c; render();}); chs.addView(b,new LinearLayout.LayoutParams(0,dp(44),1)); } r.addView(chs);
        TextView sel=tv("ช่องที่เลือก: CH"+(selectedCh+1)+" • "+ch[selectedCh].replace("\n"," "),12); sel.setTextColor(CYAN); r.addView(cardWith(sel));
        TextView steps=tv("วิธีจับ: 1) เปิด Bluetooth HCI snoop  2) เชื่อมต่อด้วย GoloPine  3) ตั้ง CH นี้เป็นค่าเดิม  4) เปลี่ยนค่าเพียง 1 ครั้ง  5) หยุด/เก็บไฟล์ HCI แล้วนำ BEFORE + AFTER มาเทียบ",11); steps.setTextColor(MUTED); r.addView(steps);
        LinearLayout row=row(); Button b1=btn("① BEFORE"); Button b2=btn("② AFTER"); Button cmp=btn("③ เทียบ"); row.addView(b1,new LinearLayout.LayoutParams(0,dp(52),1)); row.addView(b2,new LinearLayout.LayoutParams(0,dp(52),1)); row.addView(cmp,new LinearLayout.LayoutParams(0,dp(52),1)); r.addView(row);
        TextView state=tv("ยังไม่ได้เลือกไฟล์",11); state.setTextColor(CYAN); r.addView(cardWith(state));
        chDiffOutput=tv("",10); chDiffOutput.setTypeface(android.graphics.Typeface.MONOSPACE); ScrollView sv=new ScrollView(this); sv.addView(chDiffOutput); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        b1.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,461);});
        b2.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,462);});
        cmp.setOnClickListener(v->compareChannelFiles(state));
        return r;
    }
    private void compareChannelFiles(TextView state){
        if(chBeforeUri==null||chAfterUri==null){state.setText("ต้องเลือก BEFORE และ AFTER ก่อน");return;}
        try{ List<HciCaptureParser.Write> a=readHci(chBeforeUri), b=readHci(chAfterUri); ArrayList<HciCaptureParser.Write> aw=new ArrayList<>(),bw=new ArrayList<>(); for(HciCaptureParser.Write w:a)if(w.handle==0x0006)aw.add(w); for(HciCaptureParser.Write w:b)if(w.handle==0x0006)bw.add(w);
            LinkedHashMap<String,Integer> ca=new LinkedHashMap<>(), cb=new LinkedHashMap<>(); for(HciCaptureParser.Write w:aw)ca.put(shortKey(w),ca.getOrDefault(shortKey(w),0)+1); for(HciCaptureParser.Write w:bw)cb.put(shortKey(w),cb.getOrDefault(shortKey(w),0)+1);
            StringBuilder out=new StringBuilder(); out.append("TARGET: CH").append(selectedCh+1).append(" ").append(ch[selectedCh].replace("\n"," ")).append("\n"); out.append("BEFORE AB01 writes: ").append(aw.size()).append("\nAFTER  AB01 writes: ").append(bw.size()).append("\n\n"); out.append("=== CHANGED / NEW AB01 PAYLOADS ===\n"); int shown=0; for(Map.Entry<String,Integer> e:cb.entrySet()){int av=ca.getOrDefault(e.getKey(),0); if(av!=e.getValue()){out.append(String.format(Locale.US,"AFTER %d | BEFORE %d | %s\n",e.getValue(),av,e.getKey())); shown++;}} if(shown==0)out.append("ไม่พบ payload เปลี่ยน\n");
            out.append("\n=== LONG CANDIDATES (LEN >= 13) ===\n"); for(HciCaptureParser.Write w:bw)if(w.data.length>=13)out.append(String.format(Locale.US,"#%d LEN=%d DATA=%s\n",w.packetIndex,w.data.length,HciCaptureParser.hex(w.data))); out.append("\nยังไม่ส่ง packet กลับเข้า DSP จนกว่าจะยืนยันว่า payload นี้เป็นคำสั่งของ CH ที่เลือกจริง\n"); chDiffOutput.setText(out.toString()); state.setText("เทียบแล้ว • พบ "+shown+" payload ที่เปลี่ยน");
        }catch(Exception e){state.setText("อ่าน/เทียบไม่สำเร็จ: "+e.getMessage()); if(chDiffOutput!=null)chDiffOutput.setText("ERROR: "+e.getMessage());}
    }

    private View masterPacketLabPage(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(14),dp(10),dp(14),dp(10));
        r.addView(section("MASTER PACKET LAB • หา packet ปรับเสียงจริง"));
        TextView note=tv("ขั้นนี้สำคัญ: เราจะเทียบ HCI 2 ไฟล์จากแอป GoloPine จริง ก่อน/หลังการกด Master 1 ครั้ง เพื่อหาคำสั่งที่เปลี่ยนจริง หน้านี้อ่านอย่างเดียวและไม่ส่ง packet เดาสุ่ม",12); note.setTextColor(MUTED); r.addView(note);
        LinearLayout row=row(); Button b1=btn("① เลือก BEFORE"); Button b2=btn("② เลือก AFTER"); Button cmp=btn("③ เปรียบเทียบ"); row.addView(b1,new LinearLayout.LayoutParams(0,dp(52),1));row.addView(b2,new LinearLayout.LayoutParams(0,dp(52),1));row.addView(cmp,new LinearLayout.LayoutParams(0,dp(52),1)); r.addView(row);
        TextView state=tv("ยังไม่ได้เลือกไฟล์",11);state.setTextColor(CYAN);r.addView(cardWith(state));
        diffOutput=tv("",10);diffOutput.setTypeface(android.graphics.Typeface.MONOSPACE);ScrollView sv=new ScrollView(this);sv.addView(diffOutput);r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        b1.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,451);});
        b2.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,452);});
        cmp.setOnClickListener(v->compareHciFiles(state));
        return r;
    }
    private List<HciCaptureParser.Write> readHci(Uri u)throws Exception{try(InputStream in=getContentResolver().openInputStream(u)){return HciCaptureParser.parse(in);}}
    private String shortKey(HciCaptureParser.Write w){return String.format(Locale.US,"%02X:%s",w.handle,HciCaptureParser.hex(w.data));}
    private void compareHciFiles(TextView state){
        if(diffBeforeUri==null||diffAfterUri==null){state.setText("ต้องเลือก BEFORE และ AFTER ก่อน");return;}
        try{
            List<HciCaptureParser.Write> a=readHci(diffBeforeUri), b=readHci(diffAfterUri);
            ArrayList<HciCaptureParser.Write> aw=new ArrayList<>(),bw=new ArrayList<>();for(HciCaptureParser.Write w:a)if(w.handle==0x0006)aw.add(w);for(HciCaptureParser.Write w:b)if(w.handle==0x0006)bw.add(w);
            StringBuilder out=new StringBuilder();out.append("BEFORE AB01 writes: ").append(aw.size()).append("\nAFTER  AB01 writes: ").append(bw.size()).append("\n\n");
            LinkedHashMap<String,Integer> ca=new LinkedHashMap<>(), cb=new LinkedHashMap<>();for(HciCaptureParser.Write w:aw)ca.put(shortKey(w),ca.getOrDefault(shortKey(w),0)+1);for(HciCaptureParser.Write w:bw)cb.put(shortKey(w),cb.getOrDefault(shortKey(w),0)+1);
            out.append("=== PAYLOADS ONLY IN AFTER / COUNT CHANGED ===\n");int shown=0;for(Map.Entry<String,Integer> e:cb.entrySet()){int av=ca.getOrDefault(e.getKey(),0);if(av!=e.getValue()){out.append(String.format(Locale.US,"AFTER count %d | BEFORE %d | %s\n",e.getValue(),av,e.getKey()));shown++;}}
            if(shown==0)out.append("ไม่พบ payload เปลี่ยน — ตรวจว่ากด Master จริงระหว่างไฟล์ AFTER และเริ่ม capture ใหม่หลัง reconnect\n");
            out.append("\n=== LONG / CANDIDATE WRITES ===\n");for(HciCaptureParser.Write w:bw)if(w.data.length>=13)out.append(String.format(Locale.US,"#%d LEN=%d DATA=%s\n",w.packetIndex,w.data.length,HciCaptureParser.hex(w.data)));
            out.append("\nสรุป: รายการด้านบนคือข้อมูลจริงจาก HCI handle 0x0006 (AB01). ยังไม่ส่งกลับไปยัง DSP จนกว่าจะยืนยัน mapping ของ Master.\n");
            diffOutput.setText(out.toString());state.setText("เปรียบเทียบแล้ว • ดู payload ที่เปลี่ยนในผลลัพธ์");
        }catch(Exception e){state.setText("อ่าน/เปรียบเทียบไม่สำเร็จ: "+e.getMessage());if(diffOutput!=null)diffOutput.setText("ERROR: "+e.getMessage());}
    }
    void load(){for(int c=0;c<7;c++)for(int b=0;b<15;b++){gain[c][b]=pref.getFloat("g"+c+"_"+b,0);q[c][b]=pref.getFloat("q"+c+"_"+b,.7f);hz[c][b]=pref.getFloat("h"+c+"_"+b,eqFreq[b]);}for(int i=0;i<7;i++){outGain[i]=pref.getFloat("o"+i,i==2?-5:-2);hp[i]=pref.getFloat("hp"+i,20);lp[i]=pref.getFloat("lp"+i,i==2?120:20000);delay[i]=pref.getFloat("d"+i,0);mute[i]=pref.getBoolean("m"+i,false);}master[0]=pref.getFloat("master",-60);presetIndex[0]=pref.getInt("preset",0);}
    void save(){android.content.SharedPreferences.Editor e=pref.edit();for(int c=0;c<7;c++)for(int b=0;b<15;b++){e.putFloat("g"+c+"_"+b,gain[c][b]);e.putFloat("q"+c+"_"+b,q[c][b]);e.putFloat("h"+c+"_"+b,hz[c][b]);}for(int i=0;i<7;i++){e.putFloat("o"+i,outGain[i]);e.putFloat("hp"+i,hp[i]);e.putFloat("lp"+i,lp[i]);e.putFloat("d"+i,delay[i]);e.putBoolean("m"+i,mute[i]);}e.putFloat("master",master[0]);e.putInt("preset",presetIndex[0]);e.apply();}

    class Fader extends View{Paint p=new Paint(1);float value=-2; int channel=0;TextView titleView;Fader(Context c){super(c);}protected void onDraw(Canvas c){float cx=getWidth()/2f,top=dp(12),bot=getHeight()-dp(15);p.setStrokeWidth(dp(5));p.setColor(Color.rgb(70,77,88));c.drawLine(cx,top,cx,bot,p);float y=bot-(value+60)/66f*(bot-top);p.setColor(CYAN);c.drawLine(cx,y,cx,bot,p);p.setColor(Color.WHITE);c.drawRoundRect(cx-dp(15),y-dp(9),cx+dp(15),y+dp(9),dp(6),dp(6),p);p.setTextSize(dp(8));p.setTextAlign(Paint.Align.CENTER);p.setColor(MUTED);for(int d=-60;d<=0;d+=12){float yy=bot-(d+60)/66f*(bot-top);c.drawText(""+d,cx-dp(26),yy+dp(3),p);}}public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){float top=dp(12),bot=getHeight()-dp(15);value=Math.max(-60,Math.min(6,(bot-e.getY())/(bot-top)*66-60));outGain[channel]=value;if(titleView!=null)titleView.setText(ch[channel]+"\n"+String.format(Locale.US,"%.1f dB",value));invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){save();if(ble!=null)ble.addLog(String.format(Locale.US,"UI CH%d %.1f dB | DSP WRITE NOT VERIFIED",channel+1,value));toast(String.format(Locale.US,"CH%d %.1f dB",channel+1,value));}return true;}}
    private void setChannelGain(int c,float value){outGain[c]=Math.max(-60f,Math.min(6f,value));save();if(ble!=null)ble.addLog(String.format(Locale.US,"UI CH%d %.1f dB | DSP WRITE NOT VERIFIED",c+1,outGain[c]));}
    class EqGraph extends View{Paint p=new Paint(1);EqGraph(Context c){super(c);}protected void onDraw(Canvas c){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(12,16,21));c.drawRect(0,0,getWidth(),getHeight(),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(GRID);for(int i=0;i<=8;i++){float y=i*getHeight()/8f;c.drawLine(0,y,getWidth(),y,p);}for(int i=0;i<15;i++){float x=i*getWidth()/14f;c.drawLine(x,0,x,getHeight(),p);}p.setColor(CYAN);p.setStrokeWidth(dp(3));Path path=new Path();for(int i=0;i<15;i++){float x=i*getWidth()/14f;float y=getHeight()/2f-gain[selectedCh][i]*(getHeight()/28f);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);p.setTextSize(dp(9));p.setTextAlign(Paint.Align.CENTER);for(int i=0;i<15;i++){float x=i*getWidth()/14f;float y=getHeight()/2f-gain[selectedCh][i]*(getHeight()/28f);p.setColor(CYAN);c.drawCircle(x,y,dp(7),p);p.setColor(Color.BLACK);c.drawText(""+(i+1),x,y+dp(3),p);}p.setColor(MUTED);p.setTextAlign(Paint.Align.LEFT);c.drawText("+12 dB",dp(4),dp(12),p);c.drawText("0",dp(4),getHeight()/2f,p);c.drawText("-12 dB",dp(4),getHeight()-dp(5),p);}}

    void requestPerms(){ArrayList<String> p=new ArrayList<>();if(Build.VERSION.SDK_INT>=31){p.add(Manifest.permission.BLUETOOTH_SCAN);p.add(Manifest.permission.BLUETOOTH_CONNECT);}else if(Build.VERSION.SDK_INT>=23)p.add(Manifest.permission.ACCESS_FINE_LOCATION);if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),10);}
    @Override public void onDevice(String n,String a,int r){runOnUiThread(()->{String s=n+"  •  "+a+"  •  "+r+" dBm";if(!devices.contains(s))devices.add(s);deviceInfo.setText("● พบ DSP\n  "+n+"\n  "+a+"  "+r+" dBm");});}
    @Override public void onLog(String s){runOnUiThread(()->{status.setText("● "+s);showMonitorLog();});}
    @Override public void onState(String s){runOnUiThread(()->{status.setText("● "+s);if(s.contains("พร้อมใช้งาน")){connected=true;deviceInfo.setText("● BP1048P4 7CH DSP\n  LE-GoloPine_DSP_A\n  GATT READY");}});}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private View monitorPage() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));

        TextView title = tv("BLE MONITOR", 24);
        root.addView(title);

        TextView help = tv("ดูข้อมูล TX/RX จาก DSP • ใช้ตรวจสอบโปรโตคอลจริง", 14);
        root.addView(help);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button clear = new Button(this);
        clear.setText("ล้าง LOG");
        clear.setOnClickListener(v -> {
            if (ble != null) ble.clearLog();
            showMonitorLog();
        });

        Button test = new Button(this);
        test.setText("ส่ง READ TEST");
        test.setOnClickListener(v -> {
            if (ble != null) { ble.addLog("=== READ TEST PRESSED ==="); ble.requestFirmware(); }
            showMonitorLog();
        });

        Button capture = new Button(this);
        capture.setText("CAPTURE BLE");
        capture.setOnClickListener(v -> {
            if (ble != null) ble.captureBleProtocol();
            showMonitorLog();
        });

        row.addView(clear, new LinearLayout.LayoutParams(0, dp(52), 1));
        row.addView(test, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(row);
        root.addView(capture, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView log = new TextView(this);
        log.setTextColor(Color.WHITE);
        log.setTextSize(12);
        log.setGravity(Gravity.TOP | Gravity.START);
        log.setPadding(dp(10), dp(10), dp(10), dp(10));
        log.setTypeface(Typeface.MONOSPACE);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.rgb(18,20,25));
        sv.addView(log);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        monitorLogView = log;
        showMonitorLog();
        return root;
    }

    private void showMonitorLog() {
        if (monitorLogView == null) return;
        monitorLogView.setText(ble == null ? "BLE controller not ready" : ble.getLogText());
    }

}
