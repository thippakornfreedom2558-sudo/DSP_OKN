# BP1048P4 7CH DSP Android App

แอปต้นแบบ Android แนวตั้งตามหน้าตาที่ผู้ใช้ส่งมา:
- 7 ช่อง CH1–CH7
- Main / EQ / Crossover / Delay / Mixer / Preset / Settings
- 15-band EQ
- swipe ซ้าย/ขวา
- เนื้อหาแต่ละหมวดเรียงลงเต็มหน้าจอ
- โครง Bluetooth permissions และ UI connection
- GitHub Actions สำหรับสร้าง APK อัตโนมัติ

## สำคัญ
ตัวแอปนี้ build ได้และ UI ทำงานได้ แต่ **การเขียนค่าจริงลงชิป BP1048P4 ยังต้องใช้ protocol/packet ของบอร์ด 7CH ที่คุณมี** เพราะชิปอย่างเดียวไม่ได้กำหนด Bluetooth protocol ของบอร์ดแต่ละผู้ผลิต

## สร้าง APK
อัปโหลดโฟลเดอร์นี้ขึ้น GitHub แล้วเปิด Actions > Build Android APK > Run workflow
จากนั้นดาวน์โหลด artifact `BP1048P4-DSP-debug`.

