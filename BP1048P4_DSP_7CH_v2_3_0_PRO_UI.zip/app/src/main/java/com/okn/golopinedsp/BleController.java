package com.okn.golopinedsp;

import android.Manifest;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import java.util.*;

public class BleController {
    private final StringBuilder debugLog = new StringBuilder();
    private static final int MAX_LOG = 20000;
    private void logLine(String x){ synchronized(debugLog){ debugLog.append(x).append('\n'); if(debugLog.length()>MAX_LOG) debugLog.delete(0,debugLog.length()-MAX_LOG); } }
    private void emit(String x){ logLine(x); listener.onLog(x); }
    public String getLogText(){ synchronized(debugLog){return debugLog.toString();} }
    public void clearLog(){ synchronized(debugLog){debugLog.setLength(0);} }
    public interface Listener{void onLog(String s);void onState(String s);void onDevice(String name,String address,int rssi);}
    public static final UUID SERVICE_AB00=UUID.fromString("0000AB00-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB01=UUID.fromString("0000AB01-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB02=UUID.fromString("0000AB02-0000-1000-8000-00805F9B34FB");
    public static final UUID CHAR_AB03=UUID.fromString("0000AB03-0000-1000-8000-00805F9B34FB");
    public static final UUID CCCD=UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");
    private final Context ctx; private final Listener listener; private BluetoothGatt gatt; private BluetoothGattCharacteristic tx,rx02,rx03; private boolean scanning; private int notifyStep=0;
    private final Handler h=new Handler(Looper.getMainLooper());
    private boolean testRunning=false;
    private int lastWriteRc=0;
    public BleController(Context c,Listener l){ctx=c;listener=l;}
    private boolean can(String p){return Build.VERSION.SDK_INT<23||ctx.checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
    public void scan(){
        if(Build.VERSION.SDK_INT>=31&&!can(Manifest.permission.BLUETOOTH_SCAN)){emit("ต้องอนุญาต Nearby devices");return;}
        BluetoothManager bm=(BluetoothManager)ctx.getSystemService(Context.BLUETOOTH_SERVICE);BluetoothAdapter a=bm.getAdapter();
        if(a==null||!a.isEnabled()){emit("เปิด Bluetooth ก่อน");return;}if(scanning)return;scanning=true;listener.onState("กำลังค้นหา BLE...");a.getBluetoothLeScanner().startScan(scanCb);h.postDelayed(this::stopScan,10000);
    }
    public void stopScan(){if(!scanning)return;scanning=false;try{BluetoothManager bm=(BluetoothManager)ctx.getSystemService(Context.BLUETOOTH_SERVICE);bm.getAdapter().getBluetoothLeScanner().stopScan(scanCb);}catch(Exception ignored){}listener.onState("สแกนเสร็จ");}
    private final ScanCallback scanCb=new ScanCallback(){@Override public void onScanResult(int type,ScanResult r){BluetoothDevice d=r.getDevice();String n=null;try{if(Build.VERSION.SDK_INT>=31&&can(Manifest.permission.BLUETOOTH_CONNECT))n=d.getName();}catch(Exception ignored){}if((n==null||n.trim().isEmpty())&&r.getScanRecord()!=null)n=r.getScanRecord().getDeviceName();if(n==null||n.trim().isEmpty())n="(ไม่มีชื่อ)";listener.onDevice(n,d.getAddress(),r.getRssi());String u=n.toUpperCase(Locale.US);boolean known=u.contains("GOLO")||u.contains("DSP")||u.contains("DST");boolean ab=false;try{ab=r.getScanRecord()!=null&&String.valueOf(r.getScanRecord().getServiceUuids()).toUpperCase(Locale.US).contains("AB00");}catch(Exception ignored){}if(known||ab){stopScan();connect(d);}}};
    public void connect(BluetoothDevice d){if(!can(Manifest.permission.BLUETOOTH_CONNECT)){emit("ไม่มี Bluetooth Connect permission");return;}closeOnly();listener.onState("กำลังเชื่อมต่อ "+d.getAddress());gatt=d.connectGatt(ctx,false,cb,BluetoothDevice.TRANSPORT_LE);}
    private void closeOnly(){if(gatt!=null){try{gatt.disconnect();gatt.close();}catch(Exception ignored){}gatt=null;}tx=null;rx02=null;rx03=null;notifyStep=0;}
    public void disconnect(){closeOnly();listener.onState("ตัดการเชื่อมต่อ");}
    public boolean isConnected(){return gatt!=null&&tx!=null;}
    public void addLog(String s){emit(s);}
    public void requestFirmware(){write(DspProtocol.firmwareInfoRequest());}
    public void requestAll(){int[] cs={0x00,0x01,0x03,0x04,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D}; int delay=0; for(int c:cs){ final int cc=c; h.postDelayed(()->write(DspProtocol.query(cc)),delay); delay+=650; } h.postDelayed(()->write(DspProtocol.effectListQuery()),delay+200); }
    public void runProtocolTests(){
        if(testRunning){emit("TEST BUSY");return;} testRunning=true;
        emit("=== PROTOCOL TEST QUEUE START ===");
        final byte[][] tests=new byte[][]{
            DspProtocol.firmwareInfoRequest(),
            DspProtocol.effectListQuery(),
            DspProtocol.query(0x01),
            DspProtocol.query(0x09),
            DspProtocol.query(0x0A)
        };
        final String[] names={"TEST 01 FIRMWARE","TEST 02 EFFECT LIST","TEST 03 SYSTEM","TEST 04 DAC0","TEST 05 DAC1"};
        for(int i=0;i<tests.length;i++){ final int k=i; h.postDelayed(()->{emit(names[k]); write(tests[k]); if(k==tests.length-1)h.postDelayed(()->{testRunning=false;emit("=== PROTOCOL TEST QUEUE END ===");},900);},i*1200L); }
    }
    public void write(byte[] data){
        if(gatt==null||tx==null){emit("TX BLOCKED: ยังไม่มี TX characteristic");return;}
        if(!can(Manifest.permission.BLUETOOTH_CONNECT)){emit("TX BLOCKED: ไม่มี Bluetooth Connect permission");return;}
        int p=tx.getProperties();int type;
        if((p&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0)type=BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
        else if((p&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0)type=BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
        else{emit("TX เขียนไม่ได้ props=0x"+Integer.toHexString(p));return;}
        try{
            int rc;
            if(Build.VERSION.SDK_INT>=33) rc=gatt.writeCharacteristic(tx,data,type);
            else {tx.setWriteType(type);tx.setValue(data);rc=gatt.writeCharacteristic(tx)?0:-1;}
            lastWriteRc=rc;
            emit("TX > "+DspProtocol.hex(data)+" | AB01 | "+(type==BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE?"NO_RESPONSE":"WRITE")+" | rc="+rc);
        }catch(Exception e){emit("TX exception: "+e.getMessage());}
    }

    public void captureBleProtocol(){
        if(testRunning){emit("CAPTURE BUSY");return;}
        if(!isConnected()){emit("CAPTURE BLOCKED: GATT/TX not ready");return;}
        testRunning=true;
        emit("=== BLE PROTOCOL CAPTURE START ===");
        emit("TARGET SERVICE="+SERVICE_AB00);
        emit("TARGET TX="+(tx==null?"none":tx.getUuid())+" RX02="+(rx02==null?"none":rx02.getUuid())+" RX03="+(rx03==null?"none":rx03.getUuid()));
        emit("Capture will send ONE frame at a time and wait between writes.");
        final byte[][] tests=new byte[][]{
            DspProtocol.firmwareInfoRequest(),
            DspProtocol.query(0x01),
            DspProtocol.query(0x03),
            DspProtocol.query(0x04),
            DspProtocol.query(0x06),
            DspProtocol.query(0x07),
            DspProtocol.query(0x09),
            DspProtocol.query(0x0A),
            DspProtocol.query(0x0B),
            DspProtocol.query(0x0C),
            DspProtocol.query(0x0D),
            DspProtocol.effectListQuery()
        };
        final String[] names={"FIRMWARE","SYSTEM","ADC0_PGA","ADC0_DIGITAL","ADC1_PGA","ADC1_DIGITAL","DAC0","DAC1","I2S0","I2S1","SPDIF","EFFECT_LIST"};
        for(int i=0;i<tests.length;i++){final int k=i;h.postDelayed(()->{
            emit("CAPTURE "+String.format(Locale.US,"%02d",k+1)+"/"+tests.length+" "+names[k]);
            write(tests[k]);
            if(k==tests.length-1)h.postDelayed(()->{testRunning=false;emit("=== BLE PROTOCOL CAPTURE END ===");},1800);
        }, 900L + i*1600L);}
    }

    private void beginNotify(){notifyStep=0;emit("=== NOTIFY SETUP AB02 + AB03 ===");subscribeNext();}
    private void subscribeNext(){
        BluetoothGattCharacteristic c=(notifyStep==0)?rx02:rx03;
        if(c==null){notifyStep++;if(notifyStep<2){subscribeNext();}else{emit("NOTIFY SETUP COMPLETE • AB02/AB03 processed");h.postDelayed(()->{emit("AUTO READ TEST: firmware request");requestFirmware();},900);listener.onState("พร้อมใช้งาน • Notify พร้อม • กด READ DSP เพื่ออ่านข้อมูล");}return;}
        if(gatt==null||!can(Manifest.permission.BLUETOOTH_CONNECT)){emit("Notify setup ข้าม: ไม่มี GATT permission");return;}
        int props=c.getProperties();boolean canNotify=(props&BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0;boolean canIndicate=(props&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0;emit("NOTIFY TRY "+c.getUuid()+" props=0x"+Integer.toHexString(props)+" notify="+canNotify+" indicate="+canIndicate);
        try{boolean local=gatt.setCharacteristicNotification(c,true);emit("NOTIFY LOCAL "+c.getUuid()+" = "+local);BluetoothGattDescriptor d=c.getDescriptor(CCCD);if(d==null){emit("CCCD MISSING "+c.getUuid());notifyStep++;h.postDelayed(this::subscribeNext,150);return;}byte[] val=canNotify?BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE:(canIndicate?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:null);if(val==null){emit("NO NOTIFY/INDICATE PROPERTY "+c.getUuid());notifyStep++;h.postDelayed(this::subscribeNext,150);return;}d.setValue(val);boolean ok=gatt.writeDescriptor(d);emit("CCCD WRITE "+c.getUuid()+" -> "+(canNotify?"NOTIFY":"INDICATE")+" queued="+ok);}
        catch(Exception e){emit("NOTIFY ERROR "+c.getUuid()+": "+e.getMessage());notifyStep++;h.postDelayed(this::subscribeNext,150);}
    }
    private void handleRx(BluetoothGattCharacteristic c,byte[] b){if(b==null)b=new byte[0];emit("RX "+c.getUuid()+" ["+b.length+" bytes] "+DspProtocol.hex(b));for(byte[] f:DspProtocol.split(b))emit("FRAME control=0x"+String.format(Locale.US,"%02X",DspProtocol.control(f))+" len="+Math.max(0,f.length-5)+" raw="+DspProtocol.hex(f));}
    private final BluetoothGattCallback cb=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){emit("GATT state="+newState+" status=0x"+Integer.toHexString(status));if(newState==BluetoothProfile.STATE_CONNECTED){listener.onState("เชื่อมต่อแล้ว • อ่าน Services...");if(can(Manifest.permission.BLUETOOTH_CONNECT))g.discoverServices();}else if(newState==BluetoothProfile.STATE_DISCONNECTED){listener.onState("หลุดการเชื่อมต่อ");tx=null;rx02=null;rx03=null;}}
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){if(status!=BluetoothGatt.GATT_SUCCESS){emit("discoverServices failed status="+status);return;}StringBuilder all=new StringBuilder();for(BluetoothGattService s:g.getServices()){all.append("S ").append(s.getUuid()).append("\n");for(BluetoothGattCharacteristic c:s.getCharacteristics())all.append("  C ").append(c.getUuid()).append(" p=0x").append(Integer.toHexString(c.getProperties())).append("\n");}emit(all.toString().trim());BluetoothGattService s=g.getService(SERVICE_AB00);if(s!=null){tx=s.getCharacteristic(CHAR_AB01);rx02=s.getCharacteristic(CHAR_AB02);rx03=s.getCharacteristic(CHAR_AB03);}if(tx==null||rx02==null||rx03==null)for(BluetoothGattService ss:g.getServices())for(BluetoothGattCharacteristic c:ss.getCharacteristics()){int p=c.getProperties();if(tx==null&&((p&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0||(p&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0))tx=c;if(rx02==null&&c.getUuid().equals(CHAR_AB02))rx02=c;if(rx03==null&&c.getUuid().equals(CHAR_AB03))rx03=c;}emit("SELECT TX="+(tx==null?"none":tx.getUuid())+" RX02="+(rx02==null?"none":rx02.getUuid())+" RX03="+(rx03==null?"none":rx03.getUuid()));
        if(rx02!=null) emit("RX02 CCCD="+(rx02.getDescriptor(CCCD)!=null)+" props=0x"+Integer.toHexString(rx02.getProperties()));
        if(rx03!=null) emit("RX03 CCCD="+(rx03.getDescriptor(CCCD)!=null)+" props=0x"+Integer.toHexString(rx03.getProperties()));if(tx==null){listener.onState("ไม่พบ TX AB01");return;}beginNotify();}
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int status){emit("CCCD CALLBACK "+d.getCharacteristic().getUuid()+" status=0x"+Integer.toHexString(status));if(status==BluetoothGatt.GATT_SUCCESS)emit("CCCD ENABLED "+d.getCharacteristic().getUuid());if(notifyStep<2){notifyStep++;h.postDelayed(BleController.this::subscribeNext,180);}}
        @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int status){emit("WRITE CALLBACK "+c.getUuid()+" status=0x"+Integer.toHexString(status));}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){handleRx(c,c.getValue());}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){handleRx(c,value);}
        @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int status){emit("READ "+c.getUuid()+" status=0x"+Integer.toHexString(status));}
    };
}
