# BP1048P4 DSP 7CH — UI v1.1

โปรเจกต์ Android แนวนอนสำหรับมือถือ โดยยึดภาพต้นแบบของผู้ใช้เป็นหลัก

หน้าหลัก:
- MAIN: Master + Fader CH1–CH7
- EQ: 15 Band และกราฟ EQ
- CROSSOVER: HPF/LPF
- DELAY: Time Alignment
- MIXER: L/R
- PRESET
- SETTINGS

หมายเหตุ: BLE layer และ protocol layer เป็นฐานสำหรับการเชื่อมต่อ BP1048P4; คำสั่ง DSP จริงต้องยืนยันกับ firmware ของบอร์ด GoloPine ก่อนใช้งานจริง


v2.0.1: แก้ compile error จากชื่อตัวแปร master ซ้ำกับ LinearLayout แล้ว


v2.1.0: เพิ่มหน้า BLE MONITOR สำหรับดู TX/RX, UUID และสถานะการเขียน เพื่อไล่โปรโตคอล GoloPine/BP1048P4
