package com.okn.bp1048dsp;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
public final class Bp1048Command {
    private Bp1048Command(){}
    public static byte[] setGain(int ch, float db){ return frame(0x10,ch,floatBytes(db)); }
    public static byte[] setDelay(int ch, float ms){ return frame(0x11,ch,floatBytes(ms)); }
    public static byte[] setEq(int ch,int band,float db){ return frame(0x12,(ch<<8)|band,floatBytes(db)); }
    public static byte[] setFilter(int ch,int type,float hz){ return frame(0x13,(ch<<8)|type,floatBytes(hz)); }
    public static byte[] setRoute(int out,int src){ return frame(0x14,(out<<8)|src,new byte[0]); }
    private static byte[] floatBytes(float v){return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(v).array();}
    private static byte[] frame(int op,int target,byte[] p){
        byte[] b=new byte[10+p.length]; b[0]='B'; b[1]='P'; b[2]=1; b[3]=(byte)op;
        b[4]=(byte)(target&255); b[5]=(byte)((target>>>8)&255);
        b[6]=(byte)p.length; System.arraycopy(p,0,b,7,p.length);
        int crc=0; for(int i=0;i<7+p.length;i++) crc=(crc+(b[i]&255))&255;
        b[7+p.length]=(byte)crc; b[8+p.length]=0x0D; b[9+p.length]=0x0A; return b;
    }
    public static String hex(byte[] x){StringBuilder s=new StringBuilder();for(byte b:x)s.append(String.format("%02X ",b&255));return s.toString().trim();}
}