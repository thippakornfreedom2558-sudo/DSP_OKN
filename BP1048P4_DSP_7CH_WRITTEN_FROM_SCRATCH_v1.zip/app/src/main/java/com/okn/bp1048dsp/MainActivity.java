package com.okn.bp1048dsp;
import android.app.*;import android.os.*;import android.Manifest;import android.content.pm.PackageManager;import android.bluetooth.*;import android.bluetooth.le.*;import android.view.*;import android.widget.*;import java.util.*;
public class MainActivity extends Activity {
    LinearLayout root; TextView status,log; BleDspTransport ble; DspModel model=new DspModel(); int selected=0;
    public void onCreate(Bundle b){super.onCreate(b); build(); request();}
    void request(){if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},9);}
    TextView t(String s){TextView v=new TextView(this);v.setText(s);v.setTextSize(18);v.setPadding(20,18,20,18);return v;}
    void build(){
      root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);
      TextView title=t("BP1048P4 • DSP 7CH");title.setTextSize(24);root.addView(title);
      status=t("สถานะ: ยังไม่เชื่อมต่อ");root.addView(status);
      Button scan=new Button(this);scan.setText("ค้นหา / เชื่อมต่อ DSP");root.addView(scan);
      LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
      for(int i=0;i<7;i++){final int ch=i;Button x=new Button(this);x.setText("CH"+(i+1));x.setOnClickListener(v->{selected=ch;status.setText("CH"+(ch+1));});tabs.addView(x,new LinearLayout.LayoutParams(0,-2,1));}
      root.addView(tabs);
      SeekBar gain=new SeekBar(this);gain.setMax(240);gain.setProgress(120);root.addView(t("GAIN"));root.addView(gain);
      SeekBar delay=new SeekBar(this);delay.setMax(500);root.addView(t("DELAY ms"));root.addView(delay);
      Button sendGain=new Button(this);sendGain.setText("ส่ง GAIN ไป DSP");root.addView(sendGain);
      Button sendDelay=new Button(this);sendDelay.setText("ส่ง DELAY ไป DSP");root.addView(sendDelay);
      root.addView(t("EQ 15 BAND")); for(int i=0;i<15;i++){final int band=i;SeekBar e=new SeekBar(this);e.setMax(240);e.setProgress(120);root.addView(e);e.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){if(f&&ble!=null)ble.send(Bp1048Command.setEq(selected,band,(p-120)/10f));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});}
      log=t("LOG\n");root.addView(log,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
      ble=new BleDspTransport(this,new BleDspTransport.Listener(){public void log(String s){runOnUiThread(()->log.append(s+"\n"));}public void connected(boolean ok){runOnUiThread(()->status.setText(ok?"เชื่อมต่อ DSP แล้ว":"ตัดการเชื่อมต่อ"));}});
      scan.setOnClickListener(v->scan());
      sendGain.setOnClickListener(v->ble.send(Bp1048Command.setGain(selected,(gain.getProgress()-120)/10f)));
      sendDelay.setOnClickListener(v->ble.send(Bp1048Command.setDelay(selected,delay.getProgress()/10f)));
    }
    void scan(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED)return;BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){log.append("ไม่มี Bluetooth\n");return;}a.getBluetoothLeScanner().startScan(new ScanCallback(){public void onScanResult(int t,ScanResult r){BluetoothDevice d=r.getDevice();String n=d.getName();if(n!=null&&(n.toLowerCase().contains("bp1048")||n.toLowerCase().contains("dsp")||n.toLowerCase().contains("dst")||n.toLowerCase().contains("golo"))){log.append("พบ "+n+"\n");a.getBluetoothLeScanner().stopScan(this);ble.connect(d);}}});new Handler().postDelayed(()->a.getBluetoothLeScanner().stopScan(new ScanCallback(){}),8000);}
}