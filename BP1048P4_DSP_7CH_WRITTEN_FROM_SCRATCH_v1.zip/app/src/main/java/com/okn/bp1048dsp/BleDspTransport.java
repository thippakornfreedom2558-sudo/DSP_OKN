package com.okn.bp1048dsp;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.os.*;
import java.util.*;
import java.util.UUID;
public final class BleDspTransport {
    public interface Listener { void log(String s); void connected(boolean ok); }
    public static final UUID SERVICE=UUID.fromString("0000AB00-0000-1000-8000-00805F9B34FB");
    public static final UUID TX=UUID.fromString("0000AB01-0000-1000-8000-00805F9B34FB");
    public static final UUID RX=UUID.fromString("0000AB02-0000-1000-8000-00805F9B34FB");
    private final Context ctx; private final Listener listener; private BluetoothGatt gatt; private BluetoothGattCharacteristic tx;
    public BleDspTransport(Context c,Listener l){ctx=c;listener=l;}
    public void connect(BluetoothDevice d){gatt=d.connectGatt(ctx,false,cb);}
    public void send(byte[] data){
        if(tx==null){listener.log("ยังไม่ได้เชื่อมต่อ DSP");return;}
        tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT); tx.setValue(data);
        boolean ok=gatt.writeCharacteristic(tx); listener.log((ok?"TX ":"TX FAIL ")+Bp1048Command.hex(data));
    }
    private final BluetoothGattCallback cb=new BluetoothGattCallback(){
        public void onConnectionStateChange(BluetoothGatt g,int s,int n){gatt=g;if(n==BluetoothProfile.STATE_CONNECTED){listener.connected(true);g.discoverServices();}else if(n==BluetoothProfile.STATE_DISCONNECTED)listener.connected(false);}
        public void onServicesDiscovered(BluetoothGatt g,int s){BluetoothGattService sv=g.getService(SERVICE);if(sv!=null){tx=sv.getCharacteristic(TX);listener.log("พบ BP1048 GATT service");}else listener.log("ไม่พบ service ของ DSP");}
        public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){listener.log("RX "+Bp1048Command.hex(c.getValue()));}
    };
}