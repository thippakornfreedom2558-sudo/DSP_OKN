package com.okn.bp1048dsp;
public final class DspModel {
    public final float[] gain=new float[7], delay=new float[7];
    public final float[][] eq=new float[7][15];
    public DspModel(){for(int i=0;i<7;i++){gain[i]=0;delay[i]=0;}}
}