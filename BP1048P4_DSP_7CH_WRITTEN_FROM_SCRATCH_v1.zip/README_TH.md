# BP1048P4 DSP 7CH — เขียนใหม่จากศูนย์
โปรเจกต์นี้ไม่คัดลอกโค้ดหรือ UI ของแอป OEM

โครงสร้าง:
- Android native Java
- BLE transport แยกจาก DSP model
- CH1–CH7
- Gain / Delay / EQ 15 band
- protocol encoder ของโปรเจกต์แยกเป็นคลาส

ข้อสำคัญ:
โปรโตคอลคำสั่งของเฟิร์มแวร์บนบอร์ดแต่ละรุ่นยังต้องยืนยันกับ firmware จริงก่อนเปิดใช้การเขียนค่าถาวรทุกคำสั่ง ตัวแอปจึงแยก transport/protocol ไว้ชัดเจนเพื่อเปลี่ยน encoder ได้โดยไม่ต้องรื้อ UI

สร้าง APK จาก GitHub Actions ได้ทันทีด้วย workflow ใน `.github/workflows/build.yml`.
